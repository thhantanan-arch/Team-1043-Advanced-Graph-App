# CFDS Replay Stage Color Separation Fix

รอบนี้ไม่ได้เปลี่ยน state logic หรือช่วง highlight ของกราฟ แต่เปลี่ยน palette ของ stage bands สำหรับ replay dark graph โดยเฉพาะ

แก้หลัก ๆ:
- ใช้ state segmentation เดิมจาก normalized `STATE`
- แยกสีแต่ละ state ให้ชัดขึ้นบน dark graph
- ลดความเทาของ pastel เดิมที่พออยู่บน dark background แล้วดูคล้ายกันเกินไป
- event marker ใช้สีแยกตาม event มากขึ้น
- state band ยังเป็น background ไม่แย่งเส้น altitude

State palette ใหม่:
- LAUNCH_PAD = rose
- ASCENT = blue
- APOGEE = green
- DESCENT = violet
- PROBE_RELEASE = amber
- PAYLOAD_RELEASE = orange
- LANDED = slate

อัปเดตหลัก: `streamlit_app.py`
