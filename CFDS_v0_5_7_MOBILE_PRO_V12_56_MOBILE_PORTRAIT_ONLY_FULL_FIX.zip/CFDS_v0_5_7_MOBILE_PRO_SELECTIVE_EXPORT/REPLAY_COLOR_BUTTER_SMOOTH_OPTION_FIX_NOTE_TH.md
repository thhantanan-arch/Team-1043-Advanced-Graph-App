# REPLAY_COLOR_BUTTER_SMOOTH_OPTION_FIX

แก้ตาม feedback ล่าสุด:

- เปลี่ยน state palette ของ Flight Replay ให้แยกสีชัดขึ้นบน dark graph
- ลด opacity ของ state band เพื่อลดความ muddy/ทับเส้น altitude
- เพิ่ม border/boundary line ของ state band เหมือนเดิมเพื่อ visibility
- เปลี่ยน State status pill จาก cyan ทึบเป็น dark pill + cyan border เพื่อไม่แย่งสายตา
- เพิ่ม option `Animation feel`:
  - Battery Saver
  - iPhone Smooth
  - Butter
  - Ultra Butter
- ปรับ frame presets ตาม animation feel
- เพิ่ม max frames ได้ถึง 1400 เฉพาะ Ultra Butter
- clamp minimum frame duration เพื่อไม่ให้ Safari/iPhone render ไม่ทันจนกระตุก
- เพิ่ม line smoothing/line width ของ replay line
- ไม่แตะ state timing, event detection, export graph engine

แนะนำบน iPhone:
- Animation feel: Butter
- Speed: 5x
- Fine smoothness: 720 frames

ถ้ากระตุก:
- ลดเป็น iPhone Smooth
- ใช้ 420 frames

ถ้าอยาก smooth มากบนคอม:
- Ultra Butter
- 1000–1400 frames
