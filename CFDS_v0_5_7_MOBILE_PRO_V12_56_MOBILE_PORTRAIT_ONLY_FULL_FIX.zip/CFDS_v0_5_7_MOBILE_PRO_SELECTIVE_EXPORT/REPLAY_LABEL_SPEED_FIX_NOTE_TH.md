# Replay Label + Speed Fix

แก้ปัญหา preview/replay ที่อ่านยาก:

- เอา text label ของ event ออกจากใน plot area เพื่อไม่ให้ Launch/Apogee/Payload/Landing ซ้อนกัน
- เหลือ vertical event lines ในกราฟเท่านั้น
- ย้ายชื่อ event ไปไว้ใน Event Timeline chips ใต้กราฟ
- ลดความเข้มของ state bands ใน replay เพื่อไม่ให้แย่ง data line
- 1x ยังหมายถึง 1 mission second = 1 real second
- 5x/10x เป็น demo speed สำหรับดูเร็วบน iPhone
- frame duration คำนวณจาก mission duration / frame count / speed

Technical notes:
- Plotly labels/annotations do not reliably auto-avoid overlap, especially on iPhone, so event names are rendered outside the plot.
- Animation still updates only current point + time cursor for smoother browser-side playback.
