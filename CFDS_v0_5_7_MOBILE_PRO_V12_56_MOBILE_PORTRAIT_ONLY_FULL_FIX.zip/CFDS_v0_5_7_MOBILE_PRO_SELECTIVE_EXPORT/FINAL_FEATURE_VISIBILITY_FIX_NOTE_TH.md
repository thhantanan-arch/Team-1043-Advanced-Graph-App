# CFDS Final Feature + Visibility Fix

แก้รอบนี้:
- No-white widget controls: selectbox/uploader/file-chip/dropdown เป็น dark HUD
- Hide truly empty panels to reduce blank boxes
- Added GPS XY path and GPS XYZ path as primary replay options
- GPS XY/XYZ path is state-colored using CFDS state colors
- Velocity/Descent rate derives from altitude/time when no velocity column exists
- Descent-rate replay includes AAS target band 5–15 m/s
- Split motion replay: Accel magnitude/XYZ, Gyro magnitude/XYZ, Angular velocity magnitude/XYZ, Tilt magnitude/XYZ
- Added stronger Tilt aliases: TILT_ROLL_DERIVED, TILT_PITCH_DERIVED, TILT_YAW_DERIVED, ROLL/PITCH/YAW variants
- Added graph insight cards: voltage R², descent band %, altitude apogee, etc.
- Added mission calculator expander
- Added Elfaria mascot asset and lightweight mascot panel
- Improved axis labels with units

Upload `streamlit_app.py` and `elfaria_mascot.png` to GitHub.
