# CFDS Clean Streamlit Rebuild Fix

รอบนี้ไม่ได้ patch CSS มั่วเพิ่มอย่างเดียว แต่จัด Streamlit replay layer ให้สะอาดขึ้น โดยคง graph engine และ feature เดิมไว้

## Fixed
- Removed open HTML graph-card wrapper that caused empty/blank boxes above charts.
- Added one final no-white-control CSS policy layer for uploader, selectbox, dropdown, input, file chip.
- Kept Streamlit Plotly charts using `theme=None` so Plotly colors are not overridden by Streamlit theme.
- Preserved AAS 2026 descent-rate bands: 12–18 m/s and 2–8 m/s.
- Preserved CONOPS planned-vs-actual accuracy metrics.
- Preserved GPS XY, GPS XYZ, optional GPS map, split motion graphs, calculator, mascot panel, export center.
- Preserved metric cards for altitude, voltage, temperature, descent, CONOPS, multi-axis min/max/range.

## GitHub update
Replace at least:
- streamlit_app.py
- elfaria_mascot.png if missing in the repo

No worker/export graph engine files were changed.
