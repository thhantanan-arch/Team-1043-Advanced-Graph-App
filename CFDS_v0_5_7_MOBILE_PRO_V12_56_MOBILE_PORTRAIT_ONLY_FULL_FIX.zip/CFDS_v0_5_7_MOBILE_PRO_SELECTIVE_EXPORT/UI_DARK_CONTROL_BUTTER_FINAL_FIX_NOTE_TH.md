# UI Dark Control + Butter Animation Final Fix

แก้ตาม feedback ล่าสุด:
- ไม่ใช้กล่องขาวใน upload/selectbox/replay controls
- file uploader chip เป็น dark HUD + text อ่านชัด
- Graph families ใน sidebar เปลี่ยนเป็น 1 column เพื่อไม่ให้ text แตก/ซ้อนบน iPhone
- State pill เปลี่ยนจาก cyan blob เป็น dark pill + cyan border
- คง Animation feel: Battery Saver / iPhone Smooth / Butter / Ultra Butter
- คง Butter default และ interpolation/frame clamp สำหรับ replay animation
- ไม่แตะ graph export engine / state timing / event detection
