# CFDS Clean Full Feature Deep Fix

แก้แบบขุดปัญหา:

- ลบ raw HTML wrapper รอบ widget ที่ทำให้เกิดกล่องโล่ง
- ซ่อน native uploaded-file chip ของ Streamlit ที่เป็นกล่องขาว แล้วแสดง custom dark uploaded chip แทน
- เพิ่ม .streamlit/config.toml dark theme เพื่อบังคับ theme ตั้งแต่ต้น
- เพิ่ม CSS final policy สำหรับ code pill, uploader, selectbox, input, checkbox/radio, report inline code
- เปลี่ยน Mission calculator เป็น scientific calculator แบบ instrument-panel ด้วย HTML/JS component
- คง graph engine เดิม: AAS 2026 bands 12–18 และ 2–8 m/s, CONOPS accuracy, GPS XY/XYZ, split motion, metric cards, units

อัปโหลดอย่างน้อย:
- streamlit_app.py
- .streamlit/config.toml
- elfaria_mascot.png ถ้าต้องการ mascot
