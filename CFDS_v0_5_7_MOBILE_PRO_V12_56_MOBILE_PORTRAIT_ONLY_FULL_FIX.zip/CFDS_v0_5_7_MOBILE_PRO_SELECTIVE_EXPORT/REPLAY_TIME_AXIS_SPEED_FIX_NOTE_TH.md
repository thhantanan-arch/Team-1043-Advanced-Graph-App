# CFDS Replay Time Axis + Speed Fix

Fixes in this build:

- Flight Replay now prefers `T_FROM_LAUNCH_S` before `PACKET_COUNT/5`.
- Replay view trims long launch-pad history and starts at about `-3 s`, matching CFDS graph export style.
- This fixes the bug where altitude stayed flat until ~300 s because replay used packet time from the raw log start.
- Smooth browser animation now uses `st.plotly_chart()` instead of custom iframe HTML for better iPhone/Safari button response.
- Speed now means mission-time speed:
  - `1x` = 1 mission second per 1 real second
  - `2x` = two mission seconds per real second
  - `5x` and `10x` are presentation/demo speeds
- Frame duration is now computed from mission duration and frame count instead of fixed arbitrary values.

Recommended iPhone setting:
- Smooth browser animation
- 5x or 10x speed for demo
- 300–600 smoothness frames
