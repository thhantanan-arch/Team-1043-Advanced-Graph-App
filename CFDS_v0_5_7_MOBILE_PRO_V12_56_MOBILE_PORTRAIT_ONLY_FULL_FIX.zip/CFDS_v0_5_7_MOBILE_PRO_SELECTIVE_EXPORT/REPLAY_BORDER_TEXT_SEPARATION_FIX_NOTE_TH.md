# CFDS Replay Border + Text Separation Fix

Purpose:
- Keep STATE timing unchanged.
- Add visible borders around each state band so adjacent regions separate clearly on dark replay graphs.
- Move state/event text out of the plot area to prevent overlap with axis/title/graph data.

Changes:
- `add_vrect(..., line_width=1.15, line_color=state_color)` for each STATE band.
- Added solid boundary lines at each state transition.
- Hidden Plotly legend inside the graph to reduce overlap.
- Added `State colors` strip below the chart.
- Kept event names in event chips below the chart.
- Increased x/y axis title standoff and border line visibility.

Update:
- Upload `streamlit_app.py` to GitHub and commit.
