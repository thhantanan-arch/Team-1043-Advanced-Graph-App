from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
import hashlib
import json
import time
from pathlib import Path
from io import BytesIO

import streamlit as st
import streamlit.components.v1 as components

# Make matplotlib safe on headless web hosts.
os.environ.setdefault("MPLBACKEND", "Agg")

APP_TITLE = "CanSat Flight Data Studio"
SUPPORTED_TYPES = ["csv", "txt", "xlsx", "xlsm", "xls"]

GRAPH_FAMILIES = {
    "altitude": {"label": "Altitude", "hint": "main launch/apogee altitude previews", "folder_prefix": "01_alt"},
    "velocity": {"label": "Velocity", "hint": "descent-rate and rule trend graphs", "folder_prefix": "02_vel"},
    "conops": {"label": "CONOPS", "hint": "actual vs planned mission profile", "folder_prefix": "06_conops"},
    "voltage_temperature": {"label": "Voltage + Temperature", "hint": "sensor health scalar graphs", "folder_prefix": "03_vt"},
    "gps": {"label": "GPS", "hint": "3D path, ground track, GPS checks", "folder_prefix": "04_gps"},
    "multi_axis": {"label": "Motion / Multi-axis", "hint": "accel, gyro, tilt focus + compared graphs", "folder_prefix": "05_multi"},
}

PRESETS = {
    "Quick Check": ["altitude", "velocity", "conops"],
    "Sensor Health": ["voltage_temperature"],
    "GPS Pack": ["gps"],
    "Motion Pack": ["multi_axis"],
    "Report Pack": ["altitude", "velocity", "voltage_temperature", "gps", "conops"],
    "Full Export": list(GRAPH_FAMILIES.keys()),
    "Custom": ["altitude", "velocity", "conops"],
}


st.set_page_config(
    page_title="CFDS Web",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
    <style>
    .block-container { padding-top: 0.75rem; padding-bottom: 1.5rem; max-width: 1180px; }
    div[data-testid="stSidebar"] { min-width: 250px; }
    .cfds-hero {
        padding: 0.95rem 1rem;
        border-radius: 20px;
        border: 1px solid rgba(148, 163, 184, 0.25);
        background: linear-gradient(135deg, rgba(15,23,42,0.96), rgba(30,64,175,0.88));
        color: white;
        margin-bottom: 0.75rem;
    }
    .cfds-hero h1 { margin: 0; font-size: clamp(1.45rem, 4vw, 2.1rem); }
    .cfds-hero p { opacity: 0.86; margin: 0.3rem 0 0 0; }
    .cfds-card {
        padding: 0.8rem 0.9rem;
        border-radius: 16px;
        border: 1px solid rgba(148, 163, 184, 0.25);
        background: rgba(248, 250, 252, 0.72);
    }
    .stButton button, .stDownloadButton button { min-height: 3rem; border-radius: 14px; font-weight: 700; }
    .metric-card { padding: 0.65rem 0.8rem; border-radius: 14px; background: rgba(241,245,249,0.78); border: 1px solid rgba(148,163,184,0.25); }
    .replay-card { padding: 0.8rem 0.9rem; border-radius: 18px; border: 1px solid rgba(248,113,113,0.35); background: rgba(255,247,247,0.72); margin: 0.4rem 0 0.8rem 0; }
    @media (max-width: 760px) {
        .block-container { padding-left: 0.55rem; padding-right: 0.55rem; }
        .cfds-hero { border-radius: 16px; padding: 0.85rem; }
        .cfds-hero p { font-size: 0.88rem; }
    
    /* ---------- Visibility fix for mission input / upload / generation panels ---------- */
    .cfds-panel,
    .cfds-panel * {
        color: var(--cfds-text) !important;
    }
    .cfds-panel-title {
        color: var(--cfds-cyan) !important;
        text-shadow: 0 0 12px rgba(56, 213, 255, .22);
    }
    div[data-testid="stFileUploader"] {
        background: rgba(7,24,39,.72) !important;
        border: 1px solid rgba(56,213,255,.24) !important;
        border-radius: 14px !important;
        padding: .35rem .55rem !important;
    }
    div[data-testid="stFileUploader"] label,
    div[data-testid="stFileUploader"] label p,
    div[data-testid="stFileUploader"] small,
    div[data-testid="stFileUploader"] span,
    div[data-testid="stFileUploader"] div,
    div[data-testid="stFileUploader"] section,
    div[data-testid="stFileUploader"] [data-testid="stWidgetLabel"] p {
        color: #DDF8FF !important;
        opacity: 1 !important;
    }
    div[data-testid="stFileUploader"] section {
        background: rgba(14,43,69,.78) !important;
        border: 1px dashed rgba(56,213,255,.42) !important;
    }
    div[data-testid="stFileUploader"] button,
    div[data-testid="stFileUploaderDropzone"] button {
        background: linear-gradient(180deg, #0B84FF, #0067C8) !important;
        color: #FFFFFF !important;
        border: 1px solid rgba(221,248,255,.65) !important;
        font-weight: 800 !important;
    }
    div[data-testid="stFileUploaderDropzone"] svg,
    div[data-testid="stFileUploader"] svg {
        color: #38D5FF !important;
        fill: #38D5FF !important;
        opacity: 1 !important;
    }
    .stCheckbox label, .stRadio label, .stSlider label,
    .stSelectbox label, .stMultiSelect label {
        color: #DDF8FF !important;
        opacity: 1 !important;
    }
    .stCheckbox p, .stRadio p, .stSlider p,
    .stSelectbox p, .stMultiSelect p {
        color: #DDF8FF !important;
        opacity: 1 !important;
    }

    div[data-testid="stImage"] img { border-radius: 10px; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# V12.56-adapted mobile console skin. This keeps Streamlit's simple layout,
# but gives the web app the same control-studio language as the desktop UI.
st.markdown(
    """
    <style>
    :root {
        --cfds-bg: #050b12;
        --cfds-panel: #071827;
        --cfds-panel-2: #0b2136;
        --cfds-card: #0e2b45;
        --cfds-border: rgba(56, 213, 255, .28);
        --cfds-border-soft: rgba(148, 163, 184, .20);
        --cfds-text: #eaffff;
        --cfds-muted: #99b4c9;
        --cfds-cyan: #38d5ff;
        --cfds-blue: #0b84ff;
        --cfds-green: #22c55e;
        --cfds-red: #ff4b55;
        --cfds-yellow: #f59e0b;
    }
    html, body, [data-testid="stAppViewContainer"] {
        background:
          radial-gradient(circle at 15% 0%, rgba(56, 213, 255, .12), transparent 28%),
          linear-gradient(180deg, #081122 0%, #050b12 42%, #04080f 100%) !important;
        color: var(--cfds-text) !important;
    }
    [data-testid="stHeader"] { background: rgba(5, 11, 18, .72) !important; backdrop-filter: blur(12px); }
    .block-container { max-width: 1320px !important; padding-top: .8rem !important; }
    .cfds-hero { display:none !important; }
    .cfds-v12-top {
        border: 1px solid var(--cfds-border);
        background: linear-gradient(180deg, rgba(7,24,39,.96), rgba(5,11,18,.96));
        border-radius: 18px;
        box-shadow: 0 0 30px rgba(56, 213, 255, .10), inset 0 1px 0 rgba(255,255,255,.06);
        margin: 0 0 .8rem 0;
        overflow: hidden;
    }
    .cfds-v12-brand {
        display: grid; grid-template-columns: 1.1fr 1fr; gap: .8rem; align-items: center;
        padding: .95rem 1rem .75rem 1rem; border-bottom: 1px solid rgba(56,213,255,.16);
    }
    .cfds-logo { display:flex; align-items:center; gap:.8rem; }
    .cfds-mark { width:42px; height:42px; border-radius:12px; display:grid; place-items:center; color:#06111f; background:linear-gradient(135deg,#38d5ff,#0b84ff); font-weight:900; box-shadow:0 0 18px rgba(56,213,255,.35); }
    .cfds-title { font-size: clamp(1.55rem, 4.8vw, 2.6rem); letter-spacing:.08em; font-weight:900; line-height:1; color:var(--cfds-text); }
    .cfds-sub { margin-top:.25rem; color:var(--cfds-muted); font-size:.82rem; letter-spacing:.12em; text-transform:uppercase; }
    .cfds-metrics { display:grid; grid-template-columns: repeat(4,1fr); gap:.45rem; }
    .cfds-chip { border-left:1px solid rgba(56,213,255,.18); padding:.25rem .65rem; min-height:46px; }
    .cfds-chip b { display:block; color:var(--cfds-cyan); font-size:.7rem; letter-spacing:.14em; text-transform:uppercase; }
    .cfds-chip span { color:var(--cfds-text); font-size:.92rem; }
    .cfds-dock { display:grid; grid-template-columns:repeat(5,1fr); }
    .cfds-dock a { text-align:center; padding:.8rem .25rem; text-decoration:none; color:#b9cce0; border-right:1px solid rgba(56,213,255,.11); letter-spacing:.12em; font-size:.82rem; text-transform:uppercase; }
    .cfds-dock a:hover, .cfds-dock .active { color:var(--cfds-cyan); background:rgba(56,213,255,.08); box-shadow:inset 0 -3px 0 var(--cfds-cyan); }
    .cfds-panel {
        border:1px solid var(--cfds-border);
        background:linear-gradient(180deg, rgba(7,24,39,.92), rgba(5,11,18,.90));
        border-radius:18px; padding:1rem; margin:.8rem 0;
        box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
    }
    .cfds-panel-title { color:var(--cfds-cyan); letter-spacing:.12em; text-transform:uppercase; font-weight:800; margin-bottom:.55rem; }
    .cfds-card, .metric-card, .replay-card {
        background: rgba(7,24,39,.72) !important;
        color: var(--cfds-text) !important;
        border: 1px solid var(--cfds-border-soft) !important;
        border-radius: 16px !important;
    }
    h1, h2, h3, h4, p, label, span, div, .stMarkdown, .stCaptionContainer, [data-testid="stMarkdownContainer"] { color: inherit; }
    .stCaptionContainer, small { color: var(--cfds-muted) !important; }
    .stButton button, .stDownloadButton button {
        background: linear-gradient(180deg, rgba(14,43,69,.96), rgba(7,24,39,.96)) !important;
        color: var(--cfds-text) !important;
        border: 1px solid rgba(56,213,255,.32) !important;
        border-radius: 12px !important;
        box-shadow: inset 0 1px 0 rgba(255,255,255,.05);
    }
    .stButton button[kind="primary"], .stButton button:hover, .stDownloadButton button:hover {
        background: linear-gradient(180deg, #0b84ff, #0067c8) !important;
        border-color: rgba(56,213,255,.85) !important;
        color: white !important;
    }
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, rgba(7,24,39,.98), rgba(5,11,18,.98)) !important;
        border-right: 1px solid var(--cfds-border) !important;
    }
    [data-testid="stFileUploader"] section, [data-testid="stExpander"], [data-testid="stMetric"], [data-testid="stTabs"] {
        background: rgba(7,24,39,.55) !important;
        border-color: rgba(56,213,255,.16) !important;
    }

    /* ---------- Visibility fix for mission input / upload / generation panels ---------- */
    .cfds-panel,
    .cfds-panel * {
        color: var(--cfds-text) !important;
    }
    .cfds-panel-title {
        color: var(--cfds-cyan) !important;
        text-shadow: 0 0 12px rgba(56, 213, 255, .22);
    }
    div[data-testid="stFileUploader"] {
        background: rgba(7,24,39,.72) !important;
        border: 1px solid rgba(56,213,255,.24) !important;
        border-radius: 14px !important;
        padding: .35rem .55rem !important;
    }
    div[data-testid="stFileUploader"] label,
    div[data-testid="stFileUploader"] label p,
    div[data-testid="stFileUploader"] small,
    div[data-testid="stFileUploader"] span,
    div[data-testid="stFileUploader"] div,
    div[data-testid="stFileUploader"] section,
    div[data-testid="stFileUploader"] [data-testid="stWidgetLabel"] p {
        color: #DDF8FF !important;
        opacity: 1 !important;
    }
    div[data-testid="stFileUploader"] section {
        background: rgba(14,43,69,.78) !important;
        border: 1px dashed rgba(56,213,255,.42) !important;
    }
    div[data-testid="stFileUploader"] button,
    div[data-testid="stFileUploaderDropzone"] button {
        background: linear-gradient(180deg, #0B84FF, #0067C8) !important;
        color: #FFFFFF !important;
        border: 1px solid rgba(221,248,255,.65) !important;
        font-weight: 800 !important;
    }
    div[data-testid="stFileUploaderDropzone"] svg,
    div[data-testid="stFileUploader"] svg {
        color: #38D5FF !important;
        fill: #38D5FF !important;
        opacity: 1 !important;
    }
    .stCheckbox label, .stRadio label, .stSlider label,
    .stSelectbox label, .stMultiSelect label {
        color: #DDF8FF !important;
        opacity: 1 !important;
    }
    .stCheckbox p, .stRadio p, .stSlider p,
    .stSelectbox p, .stMultiSelect p {
        color: #DDF8FF !important;
        opacity: 1 !important;
    }

    div[data-testid="stImage"] img {
        border-radius: 12px !important;
        border: 1px solid rgba(56,213,255,.22);
        background: #f7fcff;
    }
    .cfds-mobile-note { color:var(--cfds-muted); font-size:.86rem; margin-top:.4rem; }
    @media (max-width: 760px) {
        .cfds-v12-brand { grid-template-columns: 1fr; }
        .cfds-metrics { grid-template-columns: repeat(2,1fr); }
        .cfds-dock { grid-template-columns: repeat(5, minmax(54px,1fr)); overflow-x:auto; }
        .cfds-dock a { font-size:.68rem; letter-spacing:.04em; padding:.7rem .15rem; }
        .cfds-chip { padding:.25rem .45rem; }
        .cfds-chip span { font-size:.82rem; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)



# --- V12.56 Replay Dashboard CSS upgrade (mobile-first, dark HUD graph workspace) ---
st.markdown(
    """
    <style>
    .cfds-replay-shell { border: 1px solid rgba(56,213,255,.30); background: radial-gradient(circle at 18% 0%, rgba(56,213,255,.10), transparent 30%), linear-gradient(180deg, rgba(7,24,39,.96), rgba(4,8,15,.96)); border-radius: 20px; padding: 1rem; margin: .9rem 0; box-shadow: 0 0 28px rgba(56,213,255,.08), inset 0 1px 0 rgba(255,255,255,.05); }
    .cfds-replay-head { display:flex; justify-content:space-between; gap:.75rem; align-items:flex-start; border-bottom:1px solid rgba(56,213,255,.16); padding-bottom:.7rem; margin-bottom:.8rem; }
    .cfds-replay-kicker { color:#38d5ff; letter-spacing:.14em; text-transform:uppercase; font-weight:800; font-size:.78rem; }
    .cfds-replay-title { color:#eaffff; font-size:clamp(1.3rem,4vw,2.0rem); font-weight:900; letter-spacing:.04em; margin:.1rem 0 0 0; }
    .cfds-replay-sub { color:#99b4c9; font-size:.88rem; margin-top:.2rem; }
    .cfds-replay-badges { display:flex; flex-wrap:wrap; gap:.45rem; justify-content:flex-end; }
    .cfds-badge { border:1px solid rgba(56,213,255,.28); border-radius:999px; padding:.32rem .62rem; color:#dbeafe; background:rgba(14,43,69,.74); font-size:.78rem; white-space:nowrap; }
    .cfds-badge b { color:#38d5ff; }
    .cfds-control-block { border:1px solid rgba(56,213,255,.18); background:rgba(5,11,18,.35); border-radius:16px; padding:.8rem; margin-bottom:.7rem; }
    .cfds-control-title { color:#38d5ff; font-size:.78rem; font-weight:800; letter-spacing:.12em; text-transform:uppercase; margin-bottom:.45rem; }
    .cfds-status-grid { display:grid; grid-template-columns:1fr 1fr; gap:.45rem; }
    .cfds-status-cell { border:1px solid rgba(148,163,184,.14); border-radius:12px; padding:.55rem; background:rgba(7,24,39,.48); }
    .cfds-status-cell span { display:block; color:#99b4c9; font-size:.68rem; letter-spacing:.09em; text-transform:uppercase; }
    .cfds-status-cell b { display:block; color:#eaffff; margin-top:.14rem; font-size:.95rem; }
    .cfds-state-pill { display:inline-block; border-radius:999px; padding:.22rem .55rem; color:#06111f !important; background:#38d5ff; font-weight:900; font-size:.72rem; letter-spacing:.05em; }
    .cfds-graph-card { border:1px solid rgba(56,213,255,.18); background:linear-gradient(180deg, rgba(7,24,39,.74), rgba(5,11,18,.52)); border-radius:18px; padding:.75rem; }
    .cfds-graph-titlebar { display:flex; justify-content:space-between; align-items:center; gap:.7rem; padding:.2rem .25rem .6rem .25rem; }
    .cfds-graph-titlebar h3 { color:#38d5ff; margin:0; letter-spacing:.08em; text-transform:uppercase; font-size:1rem; }
    .cfds-graph-titlebar span { color:#99b4c9; font-size:.78rem; }
    .cfds-mini-help { color:#99b4c9; font-size:.78rem; padding:.55rem .25rem 0 .25rem; }
    .cfds-event-strip { display:grid; grid-template-columns:repeat(auto-fit,minmax(132px,1fr)); gap:.45rem; margin:.70rem .15rem .1rem .15rem; }
    .cfds-event-chip { border:1px solid rgba(56,213,255,.20); background:rgba(7,24,39,.68); border-radius:12px; padding:.48rem .55rem; }
    .cfds-event-chip span { display:block; color:#99b4c9; font-size:.62rem; letter-spacing:.09em; text-transform:uppercase; }
    .cfds-event-chip b { display:block; color:#eaffff; font-size:.82rem; margin-top:.12rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .cfds-state-strip { display:grid; grid-template-columns:repeat(7,minmax(0,1fr)); gap:.46rem; align-items:stretch; border:1px solid rgba(56,213,255,.18); background:rgba(7,24,39,.48); border-radius:12px; margin:1.05rem .15rem .55rem .15rem; padding:.72rem .72rem .68rem .72rem; position:relative; }
    .cfds-state-strip-title { position:absolute; top:-.72rem; left:.72rem; background:#071827; color:#9db7c9; font-size:.64rem; letter-spacing:.12em; text-transform:uppercase; font-weight:900; padding:0 .42rem; }
    .cfds-state-chip { display:flex; align-items:center; justify-content:center; gap:.36rem; min-height:2.15rem; padding:.35rem .44rem; color:#eafaff; font-size:.68rem; font-weight:800; letter-spacing:.055em; white-space:nowrap; border:1px solid rgba(234,251,255,.16); border-radius:10px; background:rgba(14,43,69,.50); overflow:hidden; text-overflow:ellipsis; }
    .cfds-state-dot { width:.72rem; height:.72rem; min-width:.72rem; border-radius:999px; border:1px solid rgba(255,255,255,.78); box-shadow:0 0 0 1px rgba(0,0,0,.45); }
    .cfds-replay-tipbar { border-top:1px solid rgba(56,213,255,.14); color:#99b4c9; margin-top:.55rem; padding:.55rem .2rem .05rem .2rem; font-size:.78rem; }
    @media (max-width: 760px) { .cfds-replay-shell { padding:.68rem; border-radius:16px; } .cfds-replay-head { display:block; } .cfds-replay-badges { justify-content:flex-start; margin-top:.6rem; } .cfds-status-grid { grid-template-columns:1fr; } .cfds-graph-card { padding:.35rem; } .cfds-event-strip { grid-template-columns:1fr 1fr; gap:.35rem; } .cfds-state-strip { grid-template-columns:repeat(2,minmax(0,1fr)); gap:.38rem; padding:.68rem .50rem .55rem .50rem; } .cfds-state-chip { justify-content:flex-start; font-size:.62rem; min-height:2.05rem; } }
    </style>
    """,
    unsafe_allow_html=True,
)


def safe_filename(name: str) -> str:
    keep = []
    for ch in name:
        if ch.isalnum() or ch in {".", "_", "-", " ", "(", ")"}:
            keep.append(ch)
        else:
            keep.append("_")
    clean = "".join(keep).strip()
    return clean or "uploaded_log.csv"


def make_zip_bytes(folder: Path) -> bytes:
    """Fast ZIP creation. compresslevel=1 is much quicker on small cloud CPUs."""
    return make_filtered_zip_bytes(folder, "CFDS_graph_exports.zip", include_suffixes=None)


def make_filtered_zip_bytes(folder: Path, archive_name: str, include_suffixes: set[str] | None = None) -> bytes:
    """Create an export ZIP from a folder, optionally filtered by file suffix."""
    archive_path = folder.parent / archive_name
    if archive_path.exists():
        archive_path.unlink()
    try:
        zf_ctx = zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED, compresslevel=1)
    except TypeError:
        zf_ctx = zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED)
    with zf_ctx as zf:
        for file in sorted(folder.rglob("*")):
            if not file.is_file():
                continue
            if include_suffixes is not None and file.suffix.lower() not in include_suffixes:
                continue
            # Mobile thumbnail cache should never go into official exports.
            if "_mobile_previews" in file.parts:
                continue
            zf.write(file, file.relative_to(folder))
    return archive_path.read_bytes()


def collect_export_payload(output_dir: Path, code: int, logs: str) -> dict:
    """Store export data in session_state so buttons keep working after Streamlit reruns."""
    png_files = sorted(output_dir.rglob("*.png"), key=_score_preview)
    report_md = output_dir / "00_diagnostics" / "flight_report.md"
    normalized_csv = output_dir / "00_diagnostics" / "normalized_log.csv"

    individual_pngs = []
    for png in png_files[:80]:
        try:
            individual_pngs.append((str(png.relative_to(output_dir)), png.read_bytes()))
        except Exception:
            pass

    payload = {
        "status_code": code,
        "logs": logs[-20000:],
        "png_count": len(png_files),
        "full_zip": make_zip_bytes(output_dir),
        "png_zip": make_filtered_zip_bytes(output_dir, "CFDS_png_only_export.zip", {".png"}),
        "diagnostics_zip": make_filtered_zip_bytes(output_dir, "CFDS_diagnostics_export.zip", {".json", ".csv", ".md", ".txt"}),
        "individual_pngs": individual_pngs,
        "folder_zips": make_folder_zips(output_dir),
        "report_text": report_md.read_text(encoding="utf-8", errors="replace") if report_md.exists() else "",
        "normalized_csv": normalized_csv.read_bytes() if normalized_csv.exists() else b"",
    }
    return payload


def _download_kwargs(key: str) -> dict:
    """Keep download buttons from rerunning the whole Streamlit page.

    Streamlit's default download_button behavior is to rerun the app after a
    click. On iPhone this makes expanders/folder sections look like they
    suddenly disappeared. on_click="ignore" keeps the UI stable.
    """
    return {"key": key, "on_click": "ignore"}




def _safe_radio_choice(label: str, options: list[str], key: str, index: int = 0, help_text: str | None = None) -> str | None:
    """iPhone-safe selector.

    Streamlit selectbox is searchable and on iPhone it can leave typed filter text
    in the field with a red/invalid border. Radio buttons are less compact but
    they are tap-only, so the value cannot desync from the visible label.
    """
    if not options:
        return None
    index = max(0, min(index, len(options) - 1))
    return st.radio(
        label,
        options,
        index=index,
        key=key,
        horizontal=False,
        help=help_text,
    )

def show_export_center(payload: dict) -> None:
    st.markdown('<a id="export"></a><div class="cfds-panel"><div class="cfds-panel-title">Export control deck</div>', unsafe_allow_html=True)
    st.subheader("Export center")
    st.caption("Use these buttons directly in the web app. On iPhone, downloaded files go to Files/Downloads.")

    c1, c2 = st.columns(2)
    with c1:
        st.download_button(
            "⬇️ Export full CFDS ZIP",
            data=payload.get("full_zip", b""),
            file_name="CFDS_graph_exports.zip",
            mime="application/zip",
            use_container_width=True,
            disabled=not payload.get("full_zip"),
            **_download_kwargs("dl_full_cfds_zip"),
        )
        st.download_button(
            "🖼️ Export PNG graphs only",
            data=payload.get("png_zip", b""),
            file_name="CFDS_png_only_export.zip",
            mime="application/zip",
            use_container_width=True,
            disabled=not payload.get("png_zip"),
            **_download_kwargs("dl_png_graphs_only"),
        )
    with c2:
        st.download_button(
            "🧪 Export diagnostics",
            data=payload.get("diagnostics_zip", b""),
            file_name="CFDS_diagnostics_export.zip",
            mime="application/zip",
            use_container_width=True,
            disabled=not payload.get("diagnostics_zip"),
            **_download_kwargs("dl_diagnostics_zip"),
        )
        st.download_button(
            "📄 Export flight report",
            data=payload.get("report_text", ""),
            file_name="flight_report.md",
            mime="text/markdown",
            use_container_width=True,
            disabled=not payload.get("report_text"),
            **_download_kwargs("dl_flight_report_md"),
        )

    if payload.get("normalized_csv"):
        st.download_button(
            "📊 Export normalized CSV",
            data=payload["normalized_csv"],
            file_name="normalized_log.csv",
            mime="text/csv",
            use_container_width=True,
            **_download_kwargs("dl_normalized_csv"),
        )

    folder_zips = payload.get("folder_zips", {})
    individual_pngs = payload.get("individual_pngs", [])

    # Export browser: one folder selector controls both folder ZIP and PNG list.
    # This is more stable on iPhone than two independent widgets, and it prevents
    # the PNG selector from showing stale files after the selected folder changes.
    if folder_zips or individual_pngs:
        st.markdown("### Graph export browser")
        st.caption("Choose one graph folder, then download that folder ZIP or one PNG from that same folder.")

        png_by_folder: dict[str, list[tuple[str, bytes]]] = {}
        for rel_name, data in individual_pngs:
            folder_name = str(Path(rel_name).parent).replace("\\", "/")
            if folder_name in ["", "."]:
                folder_name = "root"
            png_by_folder.setdefault(folder_name, []).append((rel_name, data))

        folder_names = sorted(set(folder_zips.keys()) | set(png_by_folder.keys()))
        if folder_names:
            previous = st.session_state.get("export_graph_folder", folder_names[0])
            if previous not in folder_names:
                previous = folder_names[0]
            selected_folder = _safe_radio_choice(
                "Choose graph folder",
                folder_names,
                key="export_graph_folder_radio",
                index=folder_names.index(previous),
                help_text="Tap one folder. This avoids the searchable selectbox state bug on iPhone.",
            )
            st.session_state["export_graph_folder"] = selected_folder

            if selected_folder in folder_zips:
                folder_file_name = "CFDS_" + selected_folder.replace("/", "_").replace("\\", "_") + "_png.zip"
                st.download_button(
                    f"⬇️ Download selected folder ZIP: {selected_folder}",
                    data=folder_zips[selected_folder],
                    file_name=folder_file_name,
                    mime="application/zip",
                    use_container_width=True,
                    **_download_kwargs(f"dl_folder_zip_{hashlib.sha1(selected_folder.encode('utf-8')).hexdigest()[:10]}"),
                )
            else:
                st.info("This folder has PNG files, but no folder ZIP was packed for it.")

            folder_pngs = sorted(png_by_folder.get(selected_folder, []), key=lambda item: item[0])
            st.markdown("### Individual PNG download")
            if not folder_pngs:
                st.info("No individual PNG found in this folder.")
            elif len(folder_pngs) == 1:
                rel_name, data = folder_pngs[0]
                st.caption(f"1 PNG available in {selected_folder}")
                st.download_button(
                    f"⬇️ Download PNG: {Path(rel_name).name}",
                    data=data,
                    file_name=Path(rel_name).name,
                    mime="image/png",
                    use_container_width=True,
                    **_download_kwargs(f"dl_png_single_{hashlib.sha1(rel_name.encode('utf-8')).hexdigest()[:10]}"),
                )
            else:
                png_labels = [rel_name for rel_name, _ in folder_pngs]
                png_key = "export_individual_png_selector_" + hashlib.sha1(selected_folder.encode("utf-8")).hexdigest()[:10]
                selected_png = _safe_radio_choice(
                    f"Choose PNG ({len(folder_pngs)} in this folder)",
                    png_labels,
                    index=0,
                    key=png_key + "_radio",
                    help_text="Tap one PNG from the selected folder.",
                )
                png_lookup = dict(folder_pngs)
                st.download_button(
                    f"⬇️ Download PNG: {Path(selected_png).name}",
                    data=png_lookup[selected_png],
                    file_name=Path(selected_png).name,
                    mime="image/png",
                    use_container_width=True,
                    **_download_kwargs(f"dl_png_{hashlib.sha1(selected_png.encode('utf-8')).hexdigest()[:10]}"),
                )

    st.markdown('</div>', unsafe_allow_html=True)

def run_worker(input_path: Path, output_dir: Path, mode: str, speed: str, families: list[str]) -> tuple[int, str]:
    env = os.environ.copy()
    env.setdefault("MPLBACKEND", "Agg")
    cmd = [
        sys.executable,
        str(Path(__file__).with_name("run_worker.py")),
        "--csv",
        str(input_path),
        "--out",
        str(output_dir),
        "--mode",
        mode,
        "--speed",
        speed,
        "--families",
        ",".join(families),
    ]
    proc = subprocess.run(
        cmd,
        cwd=str(Path(__file__).parent),
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    return proc.returncode, proc.stdout


def show_report(output_dir: Path) -> None:
    report_md = output_dir / "00_diagnostics" / "flight_report.md"
    if report_md.exists():
        with st.expander("Flight report", expanded=False):
            st.markdown(report_md.read_text(encoding="utf-8", errors="replace"))

    manifest = output_dir / "studio_manifest.json"
    if manifest.exists():
        with st.expander("Studio manifest / diagnostics", expanded=False):
            st.code(manifest.read_text(encoding="utf-8", errors="replace"), language="json")


def _thumbnail_path(src: Path, cache_dir: Path, max_width: int = 900) -> Path:
    """Create a lightweight mobile preview image without changing export files."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    out = cache_dir / f"{src.stem}_preview.jpg"
    if out.exists():
        return out
    try:
        from PIL import Image
        img = Image.open(src)
        img.thumbnail((max_width, max_width * 3))
        if img.mode in ("RGBA", "LA"):
            bg = Image.new("RGB", img.size, "white")
            bg.paste(img, mask=img.getchannel("A"))
            img = bg
        else:
            img = img.convert("RGB")
        img.save(out, "JPEG", quality=72, optimize=True)
        return out
    except Exception:
        return src


def _score_preview(png: Path) -> tuple[int, str]:
    name = png.name.lower()
    rel = str(png).lower()
    # Put the most useful checks first on mobile.
    if "altitude" in name or "01_alt" in rel:
        return (0, name)
    if "velocity" in name or "02_vel" in rel:
        return (1, name)
    if "conops" in name or "06_conops" in rel:
        return (2, name)
    if "voltage" in name or "temperature" in name or "03_vt" in rel:
        return (3, name)
    if "gps" in name or "04_gps" in rel:
        return (4, name)
    return (5, name)


def _folder_label(folder: Path, output_dir: Path, count: int) -> str:
    rel = folder.relative_to(output_dir)
    name = "All folders" if str(rel) == "." else str(rel)
    return f"{name}  ({count})"


def show_previews(output_dir: Path, max_images: int, show_full_png: bool, show_all_folders: bool) -> None:
    png_files = sorted(output_dir.rglob("*.png"), key=_score_preview)
    if not png_files:
        st.warning("No PNG previews were generated. Check diagnostics or error log in the ZIP.")
        return

    thumb_dir = output_dir / "00_diagnostics" / "_mobile_previews"

    folders = sorted({p.parent for p in png_files}, key=lambda x: str(x.relative_to(output_dir)))
    folder_counts = {folder: sum(1 for p in png_files if p.parent == folder) for folder in folders}

    st.markdown('<a id="preview"></a><div class="cfds-panel"><div class="cfds-panel-title">Graph preview browser</div>', unsafe_allow_html=True)
    st.subheader("Preview browser")
    st.caption(
        f"Generated {len(png_files)} PNG files. Choose a folder to browse, or use Fast preview for the first {max_images}. "
        "Phone previews are compressed; ZIP exports keep the selected quality profile."
    )

    tab_fast, tab_folder = st.tabs(["⚡ Fast preview", "📁 Folder browser"])

    with tab_fast:
        visible = png_files[:max_images]
        st.caption(f"Showing {len(visible)} of {len(png_files)} PNG files.")
        for png in visible:
            preview_img = png if show_full_png else _thumbnail_path(png, thumb_dir)
            st.image(str(preview_img), caption=str(png.relative_to(output_dir)), use_container_width=True)

    with tab_folder:
        labels = [_folder_label(folder, output_dir, folder_counts[folder]) for folder in folders]
        selected_label = _safe_radio_choice(
            "Choose graph folder",
            labels,
            index=0,
            key="preview_graph_folder_radio",
            help_text="Tap-only folder picker for iPhone stability.",
        )
        selected_folder = folders[labels.index(selected_label)]
        folder_files = sorted([p for p in png_files if p.parent == selected_folder], key=lambda p: p.name)

        # Streamlit sliders require min_value < max_value.
        # Some selected folders contain only one image, so render that image directly
        # instead of creating a 1..1 slider that crashes the app.
        if len(folder_files) <= 1:
            folder_limit = len(folder_files)
            st.caption(
                f"Showing {folder_limit} of {len(folder_files)} image in {selected_folder.relative_to(output_dir)}"
            )
        else:
            default_limit = min(len(folder_files), 12)
            safe_folder_key = hashlib.sha1(str(selected_folder.relative_to(output_dir)).encode("utf-8")).hexdigest()[:10]
            folder_limit = st.slider(
                "Images from this folder",
                min_value=1,
                max_value=len(folder_files),
                value=default_limit,
                step=1,
                key=f"folder_preview_limit_{safe_folder_key}",
            )
            st.caption(
                f"Showing {min(folder_limit, len(folder_files))} of {len(folder_files)} images in {selected_folder.relative_to(output_dir)}"
            )

        for png in folder_files[:folder_limit]:
            preview_img = png if show_full_png else _thumbnail_path(png, thumb_dir)
            st.image(str(preview_img), caption=png.name, use_container_width=True)

    if show_all_folders:
        with st.expander("Folder summary", expanded=False):
            for folder in folders:
                st.markdown(f"**{folder.relative_to(output_dir)}** — {folder_counts[folder]} images")




def _score_preview_name(rel_name: str) -> tuple[int, str]:
    name = Path(rel_name).name.lower()
    rel = rel_name.lower()
    if "altitude" in name or "01_alt" in rel:
        return (0, name)
    if "velocity" in name or "02_vel" in rel:
        return (1, name)
    if "conops" in name or "06_conops" in rel:
        return (2, name)
    if "voltage" in name or "temperature" in name or "03_vt" in rel:
        return (3, name)
    if "gps" in name or "04_gps" in rel:
        return (4, name)
    return (5, name)


def _preview_image_bytes(png_bytes: bytes, show_full_png: bool, max_width: int = 900) -> bytes:
    """Return stable in-memory bytes for Streamlit image rendering.

    Important: Streamlit reruns the script after widget changes. The graph files are
    generated in a TemporaryDirectory that disappears after the generation run, so
    preview images must come from session-state bytes, not from local temp paths.
    """
    if show_full_png:
        return png_bytes
    try:
        from PIL import Image
        img = Image.open(BytesIO(png_bytes))
        img.thumbnail((max_width, max_width * 3))
        if img.mode in ("RGBA", "LA"):
            bg = Image.new("RGB", img.size, "white")
            bg.paste(img, mask=img.getchannel("A"))
            img = bg
        else:
            img = img.convert("RGB")
        out = BytesIO()
        img.save(out, "JPEG", quality=72, optimize=True)
        return out.getvalue()
    except Exception:
        return png_bytes


def _set_preview_folder(folder: str) -> None:
    """Persist selected preview folder through Streamlit reruns."""
    st.session_state["preview_selected_folder"] = folder


def show_previews_from_payload(payload: dict, max_images: int, show_full_png: bool, show_all_folders: bool) -> None:
    """Render preview images from cached bytes using an iPhone-safe single view.

    Earlier builds used Streamlit tabs plus a folder radio. On iPhone this felt like
    the image did not change because any widget interaction reruns the script and
    tabs/scroll position can visually reset. This version removes the tab dependency:
    the selected folder preview is always rendered directly below the folder picker.
    """
    png_items = payload.get("individual_pngs", []) or []
    if not png_items:
        st.warning("No PNG previews are available in the cached export. Try generating graphs again.")
        return

    png_items = sorted(png_items, key=lambda item: _score_preview_name(item[0]))
    by_folder: dict[str, list[tuple[str, bytes]]] = {}
    for rel_name, data in png_items:
        folder_name = str(Path(rel_name).parent).replace("\\", "/")
        if folder_name in ["", "."]:
            folder_name = "root"
        by_folder.setdefault(folder_name, []).append((rel_name, data))

    st.subheader("Preview browser")
    st.caption(
        f"Generated {len(png_items)} PNG files. Folder preview is loaded from session memory, "
        "so switching folders does not depend on deleted temp files."
    )

    folders = sorted(by_folder.keys())
    if not folders:
        st.warning("No preview folders found.")
        return

    current_folder = st.session_state.get("preview_selected_folder", folders[0])
    if current_folder not in folders:
        current_folder = folders[0]
        st.session_state["preview_selected_folder"] = current_folder

    folder_labels = [f"{folder}  ({len(by_folder[folder])})" for folder in folders]
    current_index = folders.index(current_folder)
    selected_label = st.radio(
        "Choose graph folder",
        folder_labels,
        index=current_index,
        key="preview_graph_folder_radio_single_view",
        horizontal=False,
        help="Tap a folder. The selected folder preview appears immediately below this list.",
    )
    selected_folder = folders[folder_labels.index(selected_label)]
    if selected_folder != st.session_state.get("preview_selected_folder"):
        st.session_state["preview_selected_folder"] = selected_folder

    folder_files = sorted(by_folder[selected_folder], key=lambda item: item[0])
    st.markdown(f"### {selected_folder} preview")

    if len(folder_files) <= 1:
        folder_limit = len(folder_files)
    else:
        safe_key = hashlib.sha1(selected_folder.encode("utf-8")).hexdigest()[:10]
        existing_key = f"folder_preview_limit_memory_{safe_key}"
        default_limit = min(len(folder_files), max(1, min(max_images, 12)))
        # If the number of files changes, clamp the remembered slider value.
        if existing_key in st.session_state:
            st.session_state[existing_key] = min(max(1, int(st.session_state[existing_key])), len(folder_files))
        folder_limit = st.slider(
            "Images from this folder",
            min_value=1,
            max_value=len(folder_files),
            value=st.session_state.get(existing_key, default_limit),
            step=1,
            key=existing_key,
        )

    st.caption(f"Showing {folder_limit} of {len(folder_files)} images in {selected_folder}")
    for rel_name, data in folder_files[:folder_limit]:
        st.image(BytesIO(_preview_image_bytes(data, show_full_png)), caption=Path(rel_name).name, use_container_width=True)

    with st.expander(f"⚡ Quick preview — first {min(max_images, len(png_items))} PNGs", expanded=False):
        visible = png_items[:max_images]
        st.caption("This is only a fast mixed preview. Use the folder picker above for reliable folder browsing on iPhone.")
        for rel_name, data in visible:
            st.image(BytesIO(_preview_image_bytes(data, show_full_png)), caption=rel_name, use_container_width=True)

    if show_all_folders:
        with st.expander("Folder summary", expanded=False):
            for folder in folders:
                st.markdown(f"**{folder}** — {len(by_folder[folder])} images")

    st.markdown('</div>', unsafe_allow_html=True)

def make_file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def make_cache_key(file_hash: str, selected: list[str], speed: str) -> str:
    return json.dumps({"file": file_hash, "families": sorted(selected), "speed": speed}, sort_keys=True)


def make_folder_zips(output_dir: Path) -> dict[str, bytes]:
    png_files = sorted(output_dir.rglob("*.png"))
    folders = sorted({p.parent for p in png_files}, key=lambda x: str(x.relative_to(output_dir)))
    result = {}
    for folder in folders:
        rel = str(folder.relative_to(output_dir))
        archive_name = "CFDS_" + rel.replace("/", "_").replace("\\", "_") + "_png.zip"
        result[rel] = make_filtered_zip_bytes(folder, archive_name, {".png"})
    return result



def _numeric_series(df, names: list[str]):
    """Return the first numeric column found from a list of candidate names."""
    for name in names:
        if name in df.columns:
            try:
                return name, __import__("pandas").to_numeric(df[name], errors="coerce")
            except Exception:
                continue
    return None, None


def _replay_dataframe_from_payload(payload: dict):
    """Load the normalized CSV stored in the export payload for Flight Replay."""
    csv_bytes = payload.get("normalized_csv") or b""
    if not csv_bytes:
        return None, "No normalized CSV found. Generate graphs first, then open Flight Replay."
    try:
        import pandas as pd
        df = pd.read_csv(BytesIO(csv_bytes))
    except Exception as exc:
        return None, f"Could not read normalized CSV for replay: {exc}"

    if df.empty:
        return None, "Normalized CSV is empty."

    # Stable mission-time axis for replay.
    # IMPORTANT: exported graphs use T_FROM_LAUNCH_S when available, with x=0 at launch.
    # PACKET_COUNT/5 from the beginning of the raw log can include minutes of launch-pad data,
    # which makes the replay look flat until ~300 s. Prefer the normalized launch-relative axis.
    if "T_FROM_LAUNCH_S" in df.columns:
        t = pd.to_numeric(df["T_FROM_LAUNCH_S"], errors="coerce")
    elif "T_REL" in df.columns:
        t = pd.to_numeric(df["T_REL"], errors="coerce")
    elif "PACKET_COUNT" in df.columns:
        t = pd.to_numeric(df["PACKET_COUNT"], errors="coerce") / 5.0
        # Best-effort launch alignment: if state/altitude can identify launch, subtract that time.
        try:
            launch_mask = pd.Series(False, index=df.index)
            if "STATE" in df.columns:
                s = df["STATE"].astype(str).str.upper()
                launch_mask = s.str.contains("ASCENT|LAUNCH", regex=True, na=False) & ~s.str.contains("PAD", na=False)
            alt_col, alt = _numeric_series(df, ["ALTITUDE", "ALT", "ALTITUDE_M"])
            if alt_col is not None:
                alt0 = float(alt.dropna().iloc[0]) if alt.dropna().size else 0.0
                launch_mask = launch_mask | (alt > alt0 + 5.0)
            if launch_mask.any():
                t = t - float(t.loc[launch_mask].iloc[0])
            else:
                t = t - t.min(skipna=True)
        except Exception:
            t = t - t.min(skipna=True)
    else:
        t = pd.Series(range(len(df)), dtype="float")

    t = t.ffill().fillna(0.0)
    df = df.copy()
    df["__REPLAY_TIME_S"] = t

    # Keep only the same visible launch window style as CFDS graphs: a little pad time before launch,
    # then the flight. This removes long flat pre-launch periods from replay.
    try:
        df = df[df["__REPLAY_TIME_S"] >= -3.0].copy()
    except Exception:
        pass
    if df.empty:
        return None, "No replay data inside the launch-relative window."
    return df.reset_index(drop=True), ""


def _downsample_for_replay(df, max_points: int):
    """Create a uniformly timed replay dataframe.

    Earlier versions downsampled by row index. That made the Plotly player feel jerky
    because mission-time spacing between frames was uneven. For replay we instead
    resample onto an even time grid, interpolate numeric telemetry, and forward-fill
    categorical fields such as STATE. The export graph engine is untouched.
    """
    import numpy as np
    import pandas as pd

    if df is None or df.empty or "__REPLAY_TIME_S" not in df.columns:
        return df.reset_index(drop=True) if df is not None else df

    try:
        max_points = int(max(20, max_points))
    except Exception:
        max_points = 300

    d = df.copy()
    d["__REPLAY_TIME_S"] = pd.to_numeric(d["__REPLAY_TIME_S"], errors="coerce")
    d = d.dropna(subset=["__REPLAY_TIME_S"]).sort_values("__REPLAY_TIME_S")
    d = d.drop_duplicates(subset=["__REPLAY_TIME_S"], keep="last").reset_index(drop=True)
    if d.empty or len(d) < 2:
        return d.reset_index(drop=True)

    t = d["__REPLAY_TIME_S"].to_numpy(dtype=float)
    if len(d) <= max_points:
        # Still normalize order/index; don't add frames unless requested.
        return d.reset_index(drop=True)

    new_t = np.linspace(float(t[0]), float(t[-1]), max_points)
    out = pd.DataFrame({"__REPLAY_TIME_S": new_t})

    for col in d.columns:
        if col == "__REPLAY_TIME_S":
            continue
        ser_num = pd.to_numeric(d[col], errors="coerce")
        numeric_ratio = float(ser_num.notna().mean()) if len(ser_num) else 0.0
        if numeric_ratio >= 0.70:
            valid = ser_num.notna().to_numpy()
            if valid.sum() >= 2:
                out[col] = np.interp(new_t, t[valid], ser_num.to_numpy(dtype=float)[valid])
            elif valid.sum() == 1:
                out[col] = float(ser_num[valid].iloc[0])
            else:
                out[col] = np.nan
        else:
            # Forward-fill text/category values onto the new time grid.
            left = pd.DataFrame({"__REPLAY_TIME_S": new_t})
            right = d[["__REPLAY_TIME_S", col]].copy().sort_values("__REPLAY_TIME_S")
            merged = pd.merge_asof(left, right, on="__REPLAY_TIME_S", direction="backward")
            if merged[col].isna().any():
                merged[col] = merged[col].bfill().ffill()
            out[col] = merged[col].to_numpy()

    # Keep time columns aligned when present.
    if "T_FROM_LAUNCH_S" in out.columns:
        out["T_FROM_LAUNCH_S"] = out["__REPLAY_TIME_S"]
    return out.reset_index(drop=True)

def _replay_plot_data(df, graph_type: str):
    """Choose columns and display labels for the selected replay graph."""
    import pandas as pd
    graph_map = {
        "Altitude": (["ALTITUDE", "ALT", "ALTITUDE_M"], "Altitude (m)"),
        "Velocity / Descent rate": (["DESCENT_RATE_DERIVED", "VELOCITY_DERIVED", "VELOCITY"], "Velocity / descent rate"),
        "Voltage": (["VOLTAGE", "VBATT", "BATTERY_VOLTAGE"], "Voltage (V)"),
        "Temperature": (["TEMPERATURE", "TEMP", "TEMP_C"], "Temperature (°C)"),
        "Pressure": (["PRESSURE", "PRES", "BARO_PRESSURE"], "Pressure"),
        "Current": (["CURRENT", "CURR", "BATTERY_CURRENT"], "Current (A)"),
        "GPS altitude": (["GPS_ALT", "GNSS_ALT", "GPS_ALTITUDE"], "GPS altitude (m)"),
    }
    if graph_type == "Motion magnitude":
        candidates = [
            (["ACCEL_R", "ACCEL_P", "ACCEL_Y"], "Acceleration magnitude"),
            (["GYRO_R", "GYRO_P", "GYRO_Y"], "Gyro magnitude"),
        ]
        for cols, label in candidates:
            if all(c in df.columns for c in cols):
                x = pd.to_numeric(df[cols[0]], errors="coerce")
                y = pd.to_numeric(df[cols[1]], errors="coerce")
                z = pd.to_numeric(df[cols[2]], errors="coerce")
                return pd.DataFrame({"Mission time (s)": df["__REPLAY_TIME_S"], label: (x*x + y*y + z*z) ** 0.5}), label
        return None, "No acceleration/gyro XYZ columns found."

    if graph_type not in graph_map:
        return None, "Unsupported replay graph."
    col, y = _numeric_series(df, graph_map[graph_type][0])
    if col is None:
        return None, f"No usable column found for {graph_type}."
    label = graph_map[graph_type][1]
    return pd.DataFrame({"Mission time (s)": df["__REPLAY_TIME_S"], label: y}), label



# --- V12.56 replay graph-state helpers copied from graph engine style ---
V1256_EXPECTED_STATES = [
    "LAUNCH_PAD", "ASCENT", "APOGEE", "DESCENT", "PROBE_RELEASE", "PAYLOAD_RELEASE", "LANDED"
]
# Replay uses a dark graph workspace, so the original pastel V12.56 bands
# are remapped to separated dark-safe hues. State logic is unchanged; only
# the visual palette is adapted so adjacent bands do not collapse into gray.
V1256_STATE_COLORS = {
    "LAUNCH_PAD": "#E11D48",      # rose / pad
    "ASCENT": "#0284C7",          # blue / climb
    "BURNOUT": "#FACC15",         # yellow / transition
    "APOGEE": "#16A34A",          # green / peak
    "DESCENT": "#7C3AED",         # violet / descent
    "PROBE_RELEASE": "#CA8A04",   # amber / probe
    "PAYLOAD_RELEASE": "#EA580C", # orange / payload
    "LANDED": "#64748B",          # slate / landed
}
V1256_STATE_DISPLAY = {
    "LAUNCH_PAD": "LAUNCH_PAD",
    "ASCENT": "ASCENT",
    "APOGEE": "APOGEE",
    "DESCENT": "DESCENT",
    "PROBE_RELEASE": "PROBE_RELEASE",
    "PAYLOAD_RELEASE": "PAYLOAD_RELEASE",
    "LANDED": "LANDED",
}
# Short UI labels keep the legend readable on iPhone. Full state names still drive the logic.
V1256_STATE_SHORT_LABELS = {
    "LAUNCH_PAD": "PAD",
    "ASCENT": "ASCENT",
    "APOGEE": "APOGEE",
    "DESCENT": "DESCENT",
    "PROBE_RELEASE": "PROBE",
    "PAYLOAD_RELEASE": "PAYLOAD",
    "LANDED": "LANDED",
}
V1256_STATE_BORDERS = {
    "LAUNCH_PAD": "#FDA4AF",
    "ASCENT": "#7DD3FC",
    "APOGEE": "#86EFAC",
    "DESCENT": "#C4B5FD",
    "PROBE_RELEASE": "#FDE68A",
    "PAYLOAD_RELEASE": "#FDBA74",
    "LANDED": "#CBD5E1",
}
V1256_STAGE_ALPHA = 0.18
V1256_LINE_COLORS = {
    "Altitude": "#126FA3",
    "Velocity / Descent rate": "#1d4ed8",
    "Voltage": "#0072B2",
    "Current": "#7c3aed",
    "Temperature": "#ea580c",
    "Pressure": "#ea580c",
    "GPS altitude": "#126FA3",
    "Motion magnitude": "#16a34a",
}


def _normalize_replay_state(value: object) -> str:
    s = str(value).upper().strip().replace(" ", "_").replace("-", "_")
    aliases = {
        "LAUNCHPAD": "LAUNCH_PAD",
        "PAD": "LAUNCH_PAD",
        "LAUNCH": "ASCENT",
        "BOOST": "ASCENT",
        "PAYLOAD_DEPLOY": "PAYLOAD_RELEASE",
        "PAYLOAD_DEPLOYMENT": "PAYLOAD_RELEASE",
        "PROBE_DEPLOY": "PROBE_RELEASE",
        "EGG_DEPLOY": "PROBE_RELEASE",
        "EGG_DEPLOYMENT": "PROBE_RELEASE",
        "LAND": "LANDED",
        "MISSION_END": "LANDED",
    }
    return aliases.get(s, s)


def _v1256_stage_segments_for_replay(df):
    """Exact V12.56-style state segmentation: contiguous STATE rows over TIME_S.

    This intentionally copies the graph engine behavior: it does not invent Coast/Main Descent
    bands. It uses the normalized STATE column and its actual contiguous time intervals.
    """
    if df is None or df.empty or "STATE" not in df.columns or "__REPLAY_TIME_S" not in df.columns:
        return []
    try:
        import pandas as pd
        d = df[["STATE", "__REPLAY_TIME_S"]].copy()
        d["STATE"] = d["STATE"].map(_normalize_replay_state)
        d["__REPLAY_TIME_S"] = pd.to_numeric(d["__REPLAY_TIME_S"], errors="coerce")
        d = d.dropna(subset=["STATE", "__REPLAY_TIME_S"]).reset_index(drop=True)
        d = d[d["STATE"].isin(V1256_EXPECTED_STATES)].reset_index(drop=True)
        if d.empty:
            return []
        segments = []
        start_idx = 0
        for i in range(1, len(d)):
            if d.loc[i, "STATE"] != d.loc[start_idx, "STATE"]:
                state = d.loc[start_idx, "STATE"]
                start = float(d.loc[start_idx, "__REPLAY_TIME_S"])
                end = float(d.loc[i, "__REPLAY_TIME_S"])
                if end > start:
                    segments.append((state, start, end))
                start_idx = i
        state = d.loc[start_idx, "STATE"]
        start = float(d.loc[start_idx, "__REPLAY_TIME_S"])
        end = float(d.loc[len(d)-1, "__REPLAY_TIME_S"])
        if end > start:
            segments.append((state, start, end))
        return segments
    except Exception:
        return []


def _event_markers_for_replay(df):
    """Event markers copied from graph-state logic: use actual STATE first, data fallback second."""
    events = []
    if df is None or df.empty or "__REPLAY_TIME_S" not in df.columns:
        return events
    try:
        import pandas as pd
        d = df.copy()
        if "STATE" in d.columns:
            d["__STATE_NORM"] = d["STATE"].map(_normalize_replay_state)
        else:
            d["__STATE_NORM"] = ""
        t = pd.to_numeric(d["__REPLAY_TIME_S"], errors="coerce")
        # Actual state first-points, matching the export graph semantics.
        state_events = [
            ("ASCENT", "Launch", "#F43F5E"),
            ("APOGEE", "Apogee", "#22C55E"),
            ("PROBE_RELEASE", "Probe", "#FACC15"),
            ("PAYLOAD_RELEASE", "Payload", "#FB923C"),
            ("LANDED", "Landing", "#94A3B8"),
        ]
        for state, label, color in state_events:
            sub = d[d["__STATE_NORM"] == state]
            if not sub.empty:
                events.append((float(pd.to_numeric(sub["__REPLAY_TIME_S"], errors="coerce").dropna().iloc[0]), label, color))
        # Fallback only if key state labels are missing.
        if not any(name == "Apogee" for _, name, _ in events):
            alt_col, alt = _numeric_series(d, ["ALTITUDE", "ALT", "ALTITUDE_M"])
            if alt_col is not None and alt.notna().any():
                imax = int(alt.idxmax())
                events.append((float(t.loc[imax]), "Apogee", "#22C55E"))
        if not any(name == "Payload" for _, name, _ in events):
            alt_col, alt = _numeric_series(d, ["ALTITUDE", "ALT", "ALTITUDE_M"])
            if alt_col is not None and alt.notna().any():
                imax = int(alt.idxmax())
                peak = float(alt.max(skipna=True))
                below = alt.loc[imax:][alt.loc[imax:] <= peak * 0.80]
                if len(below):
                    ridx = below.index[0]
                    events.append((float(t.loc[ridx]), "Payload", "#FB923C"))
        if not any(name == "Launch" for _, name, _ in events):
            events.insert(0, (max(0.0, float(t.min(skipna=True))), "Launch", "#F43F5E"))
        if not any(name == "Landing" for _, name, _ in events):
            events.append((float(t.max(skipna=True)), "Landing", "#94A3B8"))
    except Exception:
        pass
    clean = []
    for ev in sorted(events, key=lambda x: x[0]):
        if not any(abs(ev[0] - x[0]) < 0.25 and ev[1] == x[1] for x in clean):
            clean.append(ev)
    return clean


def _v1256_stage_rects(full_df):
    """Return exact V12.56 graph-engine state bands: state, start, end, color, border, alpha."""
    rects = []
    for state, start, end in _v1256_stage_segments_for_replay(full_df):
        rects.append((start, end, state, V1256_STATE_COLORS.get(state, "#eeeeee"), V1256_STATE_BORDERS.get(state, "#e5e7eb"), V1256_STAGE_ALPHA))
    return rects


def _state_legend_strip_html(full_df) -> str:
    """Compact state legend outside the plot area so text cannot overlap the graph."""
    seen = []
    for state, _start, _end in _v1256_stage_segments_for_replay(full_df):
        if state not in seen:
            seen.append(state)
    if not seen:
        seen = V1256_EXPECTED_STATES
    parts = ['<div class="cfds-state-strip"><span class="cfds-state-strip-title">State colors</span>']
    for state in seen:
        color = V1256_STATE_COLORS.get(state, '#94A3B8')
        border = V1256_STATE_BORDERS.get(state, '#EAFBFF')
        short = V1256_STATE_SHORT_LABELS.get(state, state)
        full = V1256_STATE_DISPLAY.get(state, state).replace('_', ' ')
        parts.append(f'<span class="cfds-state-chip" title="{full}" style="border-color:{border};"><i class="cfds-state-dot" style="background:{color}; border-color:{border};"></i>{short}</span>')
    parts.append('</div>')
    return ''.join(parts)

def _make_v1256_replay_fig(plot_df, label: str, full_df, graph_type: str, frame_time: float):
    import plotly.graph_objects as go
    x = plot_df["Mission time (s)"]
    y = plot_df[label]
    fig = go.Figure()
    events = _event_markers_for_replay(full_df)
    t_min = float(full_df["__REPLAY_TIME_S"].min())
    t_max = float(full_df["__REPLAY_TIME_S"].max())
    for x0, x1, state, color, border, alpha in _v1256_stage_rects(full_df):
        # Visible separation: each state band has a colored fill plus a brighter border.
        fig.add_vrect(x0=x0, x1=x1, fillcolor=color, opacity=max(0.12, min(float(alpha), 0.20)),
                      line_width=2.1, line_color=border)
        fig.add_vline(x=x0, line_width=1.15, line_color=border, line_dash="solid", opacity=0.95)
    # final boundary line
    rects_tmp = _v1256_stage_rects(full_df)
    if rects_tmp:
        fig.add_vline(x=rects_tmp[-1][1], line_width=1.15, line_color=rects_tmp[-1][4], line_dash="solid", opacity=0.95)
    line_color = V1256_LINE_COLORS.get(graph_type, "#126FA3")
    fig.add_trace(go.Scatter(
        x=x, y=y, mode="lines", name=label,
        line=dict(color=line_color, width=3, shape="spline", smoothing=0.75),
        showlegend=False,
        fill="tozeroy" if graph_type == "Altitude" else None,
        fillcolor="rgba(0,119,167,.08)" if graph_type == "Altitude" else None,
    ))
    if len(plot_df):
        fig.add_trace(go.Scatter(
            x=[x.iloc[-1]], y=[y.iloc[-1]], mode="markers", name="Current point",
            marker=dict(size=11, color="#ef4444", line=dict(color="white", width=1.6)),
            showlegend=False,
            hovertemplate="t=%{x:.1f}s<br>value=%{y:.3g}<extra></extra>",
        ))
    fig.add_vline(x=frame_time, line_width=2, line_color="#EAFBFF", line_dash="dash")
    y_min = float(y.min()) if len(y) else 0.0
    y_max = float(y.max()) if len(y) else 1.0
    if y_min == y_max:
        y_min -= 1; y_max += 1
    for tx, name, color in events:
        if tx <= frame_time + 1e-6:
            fig.add_vline(x=tx, line_width=1.3, line_color=color, line_dash="dot")
    fig.update_layout(
        title=None,
        height=500,
        margin=dict(l=62, r=24, t=44, b=48),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="#0A1724",
        font=dict(color="#DDEBFF", size=12),
        showlegend=False,
        hovermode="x unified",
    )
    fig.update_xaxes(title_text="Mission time (s)", title_standoff=28, gridcolor="rgba(203,213,225,.14)", zeroline=False, linecolor="rgba(56,213,255,.45)", mirror=True, linewidth=1.2)
    fig.update_yaxes(title_text=label, title_standoff=12, gridcolor="rgba(203,213,225,.14)", zeroline=False, linecolor="rgba(56,213,255,.45)", mirror=True, linewidth=1.2)
    return fig




def _make_v1256_replay_animation_fig(plot_df, label: str, full_df, graph_type: str, trail_mode: str, frame_duration_ms: int = 40):
    """Create a light browser-side Plotly animation for iPhone.

    Performance rule: keep the graph, state bands, labels, and full telemetry line static.
    Animate only the current point and the time cursor. This avoids re-sending/re-drawing
    a long trail line every frame, which was the main source of stutter on iPhone.
    """
    import plotly.graph_objects as go
    import pandas as pd
    import numpy as np

    if plot_df is None or plot_df.empty:
        return None
    plot_df = plot_df.dropna(subset=["Mission time (s)", label]).reset_index(drop=True)
    if plot_df.empty:
        return None

    x_all = pd.to_numeric(plot_df["Mission time (s)"], errors="coerce").to_numpy(dtype=float)
    y_all = pd.to_numeric(plot_df[label], errors="coerce").to_numpy(dtype=float)
    valid = ~(np.isnan(x_all) | np.isnan(y_all))
    x_all = x_all[valid]
    y_all = y_all[valid]
    if len(x_all) < 2:
        return None

    y_min = float(np.nanmin(y_all))
    y_max = float(np.nanmax(y_all))
    if y_min == y_max:
        y_min -= 1.0
        y_max += 1.0
    pad = (y_max - y_min) * 0.08
    y0, y1 = y_min - pad, y_max + pad

    line_color = V1256_LINE_COLORS.get(graph_type, "#126FA3")

    # Static layer: state bands, full reference line, event markers.
    fig = go.Figure()
    stage_rects = _v1256_stage_rects(full_df)
    for x0, x1, state, color, border, alpha in stage_rects:
        # Keep state text out of the plot. Use border + boundary line for visibility.
        fig.add_vrect(
            x0=x0, x1=x1, fillcolor=color, opacity=max(0.12, min(float(alpha), 0.20)),
            line_width=2.1, line_color=border
        )
        fig.add_vline(x=x0, line_width=1.15, line_color=border, line_dash="solid", opacity=0.95)
    if stage_rects:
        fig.add_vline(x=stage_rects[-1][1], line_width=1.15, line_color=stage_rects[-1][4], line_dash="solid", opacity=0.95)

    # Full line stays static. This keeps motion smooth; only point/cursor animate.
    fig.add_trace(go.Scatter(
        x=x_all,
        y=y_all,
        mode="lines",
        name=label,
        line=dict(color=line_color, width=3, shape="spline", smoothing=0.75),
        showlegend=False,
        fill="tozeroy" if graph_type == "Altitude" else None,
        fillcolor="rgba(0,119,167,.07)" if graph_type == "Altitude" else None,
        hovertemplate="t=%{x:.1f}s<br>value=%{y:.3g}<extra></extra>",
    ))

    # Optional visible-window trail: static faint band behind current point only if selected.
    # It is intentionally not animated to prevent mobile stutter.
    if trail_mode != "Full trail":
        fig.add_trace(go.Scatter(
            x=x_all,
            y=y_all,
            mode="lines",
            name="Reference trail",
            line=dict(color="rgba(234,251,255,.22)", width=1.5),
            hoverinfo="skip",
            showlegend=False,
        ))

    # Dynamic traces: current point + time cursor. These are the only traces updated per frame.
    fig.add_trace(go.Scatter(
        x=[x_all[0]],
        y=[y_all[0]],
        mode="markers",
        name="Current point",
        showlegend=False,
        marker=dict(size=12, color="#ef4444", line=dict(color="white", width=1.6)),
        hovertemplate="t=%{x:.1f}s<br>value=%{y:.3g}<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=[x_all[0], x_all[0]],
        y=[y0, y1],
        mode="lines",
        name="Time cursor",
        showlegend=False,
        line=dict(color="#EAFBFF", width=2, dash="dash"),
        hoverinfo="skip",
    ))

    events = _event_markers_for_replay(full_df)
    for tx, name, color in events:
        # Event names are shown in the Event Timeline chips under the graph.
        # Keep only a thin vertical marker in the plot so labels cannot overlap.
        fig.add_vline(x=tx, line_width=1.25, line_color=color, line_dash="dot", opacity=0.82)

    frames = []
    # Only update current point and cursor. Trace indices: static line=0, optional ref=1, current/cursor are last two.
    current_trace_index = len(fig.data) - 2
    cursor_trace_index = len(fig.data) - 1
    for i in range(len(x_all)):
        frames.append(go.Frame(
            name=str(i),
            data=[
                go.Scatter(x=[x_all[i]], y=[y_all[i]]),
                go.Scatter(x=[x_all[i], x_all[i]], y=[y0, y1]),
            ],
            traces=[current_trace_index, cursor_trace_index],
        ))
    fig.frames = frames

    # Sparse slider steps keep the JSON light while Play still uses all frames.
    steps = []
    step_stride = max(1, len(x_all) // 18)
    for i in range(0, len(x_all), step_stride):
        steps.append(dict(
            method="animate",
            args=[[str(i)], {"mode": "immediate", "frame": {"duration": 0, "redraw": False}, "transition": {"duration": 0}}],
            label=f"{x_all[i]:.0f}s",
        ))

    safe_frame_duration = int(max(20, min(1200, frame_duration_ms)))
    fig.update_layout(
        title=None,
        height=600,
        margin=dict(l=66, r=28, t=36, b=105),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="#0A1724",
        font=dict(color="#DDEBFF", size=12),
        showlegend=False,
        hovermode="x unified",
        yaxis=dict(range=[y0, y1]),
        uirevision="cfds_replay_smooth_static_layers",
        updatemenus=[dict(
            type="buttons",
            direction="left",
            x=0.012,
            y=1.08,
            xanchor="left",
            yanchor="top",
            showactive=False,
            bgcolor="rgba(7,24,39,.96)",
            bordercolor="rgba(56,213,255,.48)",
            borderwidth=1,
            pad={"r": 8, "t": 4},
            buttons=[
                dict(label="▶ Play", method="animate",
                     args=[None, {"fromcurrent": True, "frame": {"duration": safe_frame_duration, "redraw": False}, "transition": {"duration": 0}, "mode": "immediate"}]),
                dict(label="⏸ Pause", method="animate",
                     args=[[None], {"frame": {"duration": 0, "redraw": False}, "mode": "immediate", "transition": {"duration": 0}}]),
            ],
        )],
        sliders=[dict(
            active=0,
            x=0.02,
            y=-0.070,
            len=0.94,
            xanchor="left",
            yanchor="top",
            pad=dict(t=8, b=0),
            currentvalue=dict(prefix="t = ", suffix=" s", font=dict(size=12, color="#DDEBFF")),
            steps=steps,
        )],
    )
    fig.update_xaxes(title_text="Mission time (s)", title_standoff=28, gridcolor="rgba(203,213,225,.14)", zeroline=False, linecolor="rgba(56,213,255,.45)", mirror=True, linewidth=1.2)
    fig.update_yaxes(title_text=label, title_standoff=12, gridcolor="rgba(203,213,225,.14)", zeroline=False, linecolor="rgba(56,213,255,.45)", mirror=True, linewidth=1.2)
    return fig

def _state_at_time_for_replay(df, t_now: float) -> str:
    """Return normalized STATE at/just before t_now for the replay status card."""
    try:
        import pandas as pd
        if df is None or df.empty or "STATE" not in df.columns:
            return "UNKNOWN"
        d = df[["STATE", "__REPLAY_TIME_S"]].copy()
        d["__REPLAY_TIME_S"] = pd.to_numeric(d["__REPLAY_TIME_S"], errors="coerce")
        d = d.dropna(subset=["__REPLAY_TIME_S"])
        d = d[d["__REPLAY_TIME_S"] <= float(t_now)]
        if d.empty:
            return _normalize_replay_state(df["STATE"].iloc[0])
        return _normalize_replay_state(d["STATE"].iloc[-1])
    except Exception:
        return "UNKNOWN"


def _next_event_for_replay(df, t_now: float) -> str:
    try:
        events = sorted(_event_markers_for_replay(df), key=lambda x: x[0])
        for tx, label, _color in events:
            if tx > float(t_now) + 1e-6:
                return f"{label} in {tx - float(t_now):.1f} s"
        return "Mission end"
    except Exception:
        return "—"


def render_flight_replay(payload: dict, mobile_fast: bool = True) -> None:
    '''Wide V12.56 replay dashboard: graph first, controls above/below, no left rail.'''
    st.markdown('<a id="replay"></a><div class="cfds-replay-shell cfds-replay-wide-shell">', unsafe_allow_html=True)

    df, err = _replay_dataframe_from_payload(payload)
    if err:
        st.markdown(
            '<div class="cfds-replay-head"><div><div class="cfds-replay-kicker">Replay deck</div><div class="cfds-replay-title">Flight Replay</div><div class="cfds-replay-sub">Generate graphs first to create a normalized mission log.</div></div></div>',
            unsafe_allow_html=True,
        )
        st.info(err)
        st.markdown('</div>', unsafe_allow_html=True)
        return

    max_points_default = 300 if mobile_fast else 650
    replay_start = float(df["__REPLAY_TIME_S"].min())
    replay_end = float(df["__REPLAY_TIME_S"].max())
    rows = len(df)
    rate_text = "5 Hz" if "PACKET_COUNT" in df.columns else "log"

    st.markdown(f'''
        <div class="cfds-replay-head cfds-replay-wide-head">
          <div>
            <div class="cfds-replay-kicker">Replay deck</div>
            <div class="cfds-replay-title">Flight Replay</div>
            <div class="cfds-replay-sub">Wide graph mode • V12.56 state bands • modebar reset-view enabled</div>
          </div>
          <div class="cfds-replay-badges">
            <div class="cfds-badge"><b>WINDOW</b> {replay_start:.1f} → {replay_end:.1f} s</div>
            <div class="cfds-badge"><b>ROWS</b> {rows}</div>
            <div class="cfds-badge"><b>RATE</b> {rate_text}</div>
          </div>
        </div>
        ''', unsafe_allow_html=True)

    graph_options = ["Altitude", "Velocity / Descent rate", "Voltage", "Temperature", "Pressure", "Current", "GPS altitude", "Motion magnitude", "GPS path"]
    speed_options = ["0.5x", "1x", "2x", "5x", "10x"]
    trail_options = ["Full trail", "Last 10 s", "Last 30 s", "Last 60 s"]

    st.markdown('<div class="cfds-wide-controls"><div class="cfds-wide-controls-title">Replay settings</div>', unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns([1.7, 1.35, 1.55, 1.55], gap="medium")
    with c1:
        graph_type = st.selectbox("Replay graph", graph_options, index=0, key="replay_graph_type_wide")
    with c2:
        speed = st.radio("Speed", speed_options, index=3 if mobile_fast else 2, horizontal=True, key="replay_speed_wide")
    with c3:
        trail_mode = st.radio("Trail", trail_options, index=0, horizontal=True, key="replay_trail_wide")
    with c4:
        replay_engine = st.radio(
            "Replay engine",
            ["Smooth browser animation", "Manual scrub fallback"],
            index=0,
            horizontal=False,
            key="replay_engine_mode_wide",
            help="Smooth mode uses Plotly animation controls inside the chart, not Streamlit button loops.",
        )
    max_points = st.slider(
        "Smoothness / animation frames",
        min_value=120,
        max_value=900,
        value=max_points_default,
        step=20,
        help="More frames = smoother but heavier on iPhone.",
        key="replay_max_points_wide",
    )
    st.markdown('<div class="cfds-mini-help cfds-wide-help">1x = real mission speed. 5x/10x are demo speeds. Use the Plotly modebar reset-axes button to reset view after zoom/pan.</div></div>', unsafe_allow_html=True)

    replay_df = _downsample_for_replay(df, max_points)
    if replay_df.empty:
        st.warning("No replay data after downsampling.")
        st.markdown('</div>', unsafe_allow_html=True)
        return

    speed_value = 0.5 if speed == "0.5x" else float(str(speed).replace("x", ""))
    try:
        replay_span_s = float(replay_df["__REPLAY_TIME_S"].iloc[-1] - replay_df["__REPLAY_TIME_S"].iloc[0])
        frame_duration = int(max(16, min(1400, (replay_span_s * 1000.0) / max(1, (len(replay_df) - 1) * speed_value))))
    except Exception:
        frame_duration = 80

    t_preview = float(replay_df["__REPLAY_TIME_S"].iloc[min(max(0, len(replay_df)//4), len(replay_df)-1)])
    state_preview = _state_at_time_for_replay(replay_df, t_preview)
    next_event = _next_event_for_replay(replay_df, t_preview)

    st.markdown(f'''
        <div class="cfds-wide-status-strip">
          <div class="cfds-status-cell"><span>Replay time</span><b>{t_preview:.1f} / {replay_end:.1f} s</b></div>
          <div class="cfds-status-cell"><span>Frames</span><b>{len(replay_df)}</b></div>
          <div class="cfds-status-cell"><span>State</span><b><span class="cfds-state-pill">{state_preview}</span></b></div>
          <div class="cfds-status-cell"><span>Next event</span><b>{next_event}</b></div>
          <div class="cfds-status-cell"><span>View control</span><b>Modebar reset axes</b></div>
        </div>
        ''', unsafe_allow_html=True)

    st.markdown('<div class="cfds-graph-card cfds-graph-card-wide"><div class="cfds-graph-titlebar"><h3>'+graph_type+' vs Time</h3></div>', unsafe_allow_html=True)

    if replay_engine == "Smooth browser animation" and graph_type != "GPS path":
        plot_df, label = _replay_plot_data(replay_df, graph_type)
        if plot_df is None:
            st.info(label)
            st.markdown('</div></div>', unsafe_allow_html=True)
            return
        fig = _make_v1256_replay_animation_fig(plot_df, label, replay_df, graph_type, trail_mode, frame_duration_ms=frame_duration)
        if fig is None:
            st.info("Not enough numeric data to create browser-side animation. Try Manual scrub fallback.")
            st.markdown('</div></div>', unsafe_allow_html=True)
            return
        fig.update_layout(
            height=700 if not mobile_fast else 660,
            margin=dict(l=66, r=28, t=46, b=128),
            dragmode="pan",
        )
        st.plotly_chart(
            fig,
            use_container_width=True,
            theme=None,
            config={
                "displayModeBar": True,
                "displaylogo": False,
                "responsive": True,
                "scrollZoom": True,
                "modeBarButtonsToRemove": ["lasso2d", "select2d", "toImage"],
            },
        )
        st.markdown(_state_legend_strip_html(replay_df), unsafe_allow_html=True)
        chips = []
        for tx, name, _color in _event_markers_for_replay(replay_df)[:6]:
            chips.append(f'<div class="cfds-event-chip"><span>{name}</span><b>{tx:.1f} s</b></div>')
        if chips:
            st.markdown('<div class="cfds-event-strip cfds-event-strip-wide">' + ''.join(chips) + '</div>', unsafe_allow_html=True)
        st.markdown('<div class="cfds-replay-tipbar">Graph is now full-width. Use embedded ▶ Play / ⏸ Pause for replay; use Plotly modebar reset axes to reset zoom/pan.</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
        return

    if replay_engine == "Smooth browser animation" and graph_type == "GPS path":
        st.info("GPS path still uses Manual scrub fallback because map playback is not browser-animated yet.")

    total_frames = len(replay_df)
    if "replay_frame_wide" not in st.session_state:
        st.session_state["replay_frame_wide"] = 0
    st.session_state["replay_frame_wide"] = min(max(0, int(st.session_state["replay_frame_wide"])), total_frames - 1)

    frame = st.slider(
        "Mission timeline",
        min_value=0,
        max_value=total_frames - 1,
        value=st.session_state["replay_frame_wide"],
        step=1,
        key="replay_timeline_slider_wide",
        help="Manual scrub mode: move through frames directly.",
    )
    st.session_state["replay_frame_wide"] = frame
    controls = st.columns(3)
    reset = controls[0].button("↺ Reset frame", use_container_width=True, key="replay_reset_btn_wide")
    jump_end = controls[1].button("⏭ End", use_container_width=True, key="replay_end_btn_wide")
    if reset:
        st.session_state["replay_frame_wide"] = 0
        st.rerun()
    if jump_end:
        st.session_state["replay_frame_wide"] = total_frames - 1
        st.rerun()

    chart_slot = st.empty()
    frame_idx = min(max(0, int(st.session_state["replay_frame_wide"])), total_frames - 1)
    sub = replay_df.iloc[: frame_idx + 1].copy()
    if trail_mode != "Full trail" and not sub.empty:
        seconds = float(trail_mode.split()[1])
        t_now = float(sub["__REPLAY_TIME_S"].iloc[-1])
        sub = sub[sub["__REPLAY_TIME_S"] >= t_now - seconds]
    t_now = float(replay_df["__REPLAY_TIME_S"].iloc[frame_idx])
    st.markdown(f'<div class="cfds-mini-help">Replay time: <b>{t_now:.1f} s</b> / {replay_end:.1f} s • Frame {frame_idx+1}/{total_frames}</div>', unsafe_allow_html=True)

    if graph_type == "GPS path":
        import pandas as pd
        lat_col, lat = _numeric_series(sub, ["GPS_LAT", "LAT", "LATITUDE"])
        lon_col, lon = _numeric_series(sub, ["GPS_LON", "LON", "LONGITUDE"])
        if lat_col is None or lon_col is None:
            chart_slot.info("No GPS latitude/longitude columns found for path replay.")
        else:
            gps = pd.DataFrame({"lat": lat, "lon": lon}).dropna()
            gps = gps[(gps["lat"].abs() > 0.0001) & (gps["lon"].abs() > 0.0001)]
            if gps.empty:
                chart_slot.info("GPS path has no valid coordinates yet at this frame.")
            else:
                chart_slot.map(gps, use_container_width=True)
    else:
        plot_df, label = _replay_plot_data(sub, graph_type)
        if plot_df is None:
            chart_slot.info(label)
        else:
            plot_df = plot_df.dropna()
            if plot_df.empty:
                chart_slot.info("No numeric data available yet for this replay frame.")
            else:
                fig = _make_v1256_replay_fig(plot_df, label, replay_df, graph_type, t_now)
                fig.update_layout(height=620 if mobile_fast else 680, margin=dict(l=62, r=24, t=34, b=74), dragmode="pan")
                chart_slot.plotly_chart(fig, use_container_width=True, theme=None, config={"displayModeBar": True, "displaylogo": False, "responsive": True, "scrollZoom": True, "modeBarButtonsToRemove": ["lasso2d", "select2d", "toImage"]})
    st.markdown(_state_legend_strip_html(replay_df), unsafe_allow_html=True)
    chips = []
    for tx, name, _color in _event_markers_for_replay(replay_df)[:6]:
        chips.append(f'<div class="cfds-event-chip"><span>{name}</span><b>{tx:.1f} s</b></div>')
    if chips:
        st.markdown('<div class="cfds-event-strip cfds-event-strip-wide">' + ''.join(chips) + '</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

def quick_data_diagnostics(input_path: Path) -> dict:
    try:
        import pandas as pd
        suffix = input_path.suffix.lower()
        if suffix in [".xlsx", ".xlsm", ".xls"]:
            df = pd.read_excel(input_path, nrows=8)
        else:
            df = pd.read_csv(input_path, nrows=8)
        cols = [str(c) for c in df.columns]
        upper = {c.upper().replace(" ", "_") for c in cols}
        def has_any(names):
            return any(n in upper for n in names)
        return {
            "ok": True,
            "columns": cols[:18],
            "has_packet": has_any(["PACKET_COUNT", "PACKET", "PKT"]),
            "has_altitude": has_any(["ALTITUDE", "ALT", "ALTITUDE_M"]),
            "has_state": has_any(["STATE", "FLIGHT_STATE", "MODE"]),
            "has_gps": has_any(["GPS_LAT", "LAT", "LATITUDE"]) and has_any(["GPS_LON", "LON", "LONGITUDE"]),
            "has_motion": has_any(["ACCEL_R", "ACCEL_X", "GYRO_R", "GYRO_X", "TILT_ROLL_DERIVED", "ROLL"]),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def render_data_diagnostics(diag: dict) -> None:
    with st.expander("Pre-flight data check", expanded=False):
        if not diag.get("ok"):
            st.warning(f"Could not read a quick preview of the input file: {diag.get('error')}")
            return
        c1, c2, c3 = st.columns(3)
        c1.metric("Altitude column", "OK" if diag.get("has_altitude") else "Check")
        c2.metric("State column", "OK" if diag.get("has_state") else "Can infer")
        c3.metric("GPS columns", "OK" if diag.get("has_gps") else "Missing/optional")
        c4, c5 = st.columns(2)
        c4.metric("Packet/timebase", "OK" if diag.get("has_packet") else "Index fallback")
        c5.metric("Motion columns", "OK" if diag.get("has_motion") else "Missing/optional")
        st.caption("Detected columns: " + ", ".join(diag.get("columns", [])))


def render_family_selector(preset_name: str) -> list[str]:
    default = PRESETS.get(preset_name, PRESETS["Quick Check"])
    selected = []
    st.markdown("**Graph families**")
    cols = st.columns(2)
    for i, (key, meta) in enumerate(GRAPH_FAMILIES.items()):
        with cols[i % 2]:
            checked = st.checkbox(
                meta["label"],
                value=(key in default),
                key=f"family_{preset_name}_{key}",
                help=meta["hint"],
                disabled=(preset_name != "Custom"),
            )
            if checked:
                selected.append(key)
    return selected

if "cfds_last_export" not in st.session_state:
    st.session_state["cfds_last_export"] = None
if "cfds_export_cache" not in st.session_state:
    st.session_state["cfds_export_cache"] = {}


st.markdown(
    """
    <a id="import"></a>
    <div class="cfds-v12-top">
      <div class="cfds-v12-brand">
        <div class="cfds-logo">
          <div class="cfds-mark">CF</div>
          <div>
            <div class="cfds-title">CFDS</div>
            <div class="cfds-sub">CanSat Flight Data Studio • Daedalus • AAS CanSat 2026</div>
          </div>
        </div>
        <div class="cfds-metrics">
          <div class="cfds-chip"><b>Status</b><span>Web Console Ready</span></div>
          <div class="cfds-chip"><b>Mode</b><span>Mobile Pro</span></div>
          <div class="cfds-chip"><b>Replay</b><span>Log Playback</span></div>
          <div class="cfds-chip"><b>Export</b><span>ZIP / PNG / Report</span></div>
        </div>
      </div>
      <div class="cfds-dock">
        <a class="active" href="#import">Import</a>
        <a href="#generate">Generate</a>
        <a href="#preview">Preview</a>
        <a href="#replay">Replay</a>
        <a href="#export">Export</a>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("CFDS Mobile Pro")
    mobile_fast = st.toggle("Mobile fast mode", value=True, help="Compressed previews, compact layout, and phone-first defaults.")
    preset_name = st.selectbox(
        "Graph preset",
        list(PRESETS.keys()),
        index=list(PRESETS.keys()).index("Quick Check"),
        help="Generate only the graph families you need. This is the biggest speed boost on iPhone.",
    )
    selected_families = render_family_selector(preset_name)
    mode_label = "Selected export"
    mode = "all"
    speed_label = st.radio(
        "Export quality",
        ["Mobile Fast", "Report Quality"],
        index=0,
        help="Mobile Fast skips SVG and uses lighter PNGs. Report Quality keeps 300 dpi PNG + SVG for final reports.",
    )
    speed = "fast" if speed_label == "Mobile Fast" else "quality"
    if mobile_fast:
        max_preview = st.slider("Max preview images", min_value=3, max_value=80, value=12, step=1)
        show_full_png = False
        show_all_folders = st.checkbox("Show folder summary", value=False)
    else:
        max_preview = st.slider("Max preview images", min_value=3, max_value=80, value=24, step=3)
        show_full_png = st.checkbox("Show original full PNG previews", value=False)
        show_all_folders = st.checkbox("Show folder summary", value=False)
    use_cached = st.checkbox("Use cached result if same log/settings", value=True, help="Skip regeneration if this exact log + selected pack was already generated in this session.")
    clear_cache_now = st.button("Clear session cache", use_container_width=True)
    if clear_cache_now:
        st.session_state["cfds_export_cache"] = {}
        st.session_state["cfds_last_export"] = None
        st.success("Cache cleared.")
    use_demo = st.checkbox("Use included demo log", value=False)
    show_logs_when_success = st.checkbox("Show worker logs after success", value=False)

st.markdown(
    """
    <div class="cfds-card">
    <b>Phone speed tip:</b> choose a preset first. Generating only Altitude + Velocity + CONOPS is much faster than building every graph family. Use Mobile Fast for field checks and Report Quality only for final files.
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown('<div class="cfds-panel"><div class="cfds-panel-title">Mission input</div>', unsafe_allow_html=True)
uploaded = None
if not use_demo:
    uploaded = st.file_uploader("Upload flight log", type=SUPPORTED_TYPES)

st.markdown('</div><a id="generate"></a><div class="cfds-panel"><div class="cfds-panel-title">Generation command</div>', unsafe_allow_html=True)
start = st.button("Generate selected graphs", type="primary", use_container_width=True)
st.markdown('</div>', unsafe_allow_html=True)

if start:
    with tempfile.TemporaryDirectory(prefix="cfds_web_") as tmp:
        work = Path(tmp)
        input_dir = work / "input"
        output_dir = work / "outputs"
        input_dir.mkdir(parents=True, exist_ok=True)
        output_dir.mkdir(parents=True, exist_ok=True)

        if use_demo:
            demo_path = Path(__file__).parent / "data" / "normalized_flight1043.csv"
            if not demo_path.exists():
                st.error("Demo file not found: data/normalized_flight1043.csv")
                st.stop()
            input_path = input_dir / demo_path.name
            shutil.copy2(demo_path, input_path)
        else:
            if uploaded is None:
                st.error("Upload a CSV/XLSX log first, or enable the demo log in the sidebar.")
                st.stop()
            input_path = input_dir / safe_filename(uploaded.name)
            input_path.write_bytes(uploaded.getbuffer())

        file_hash = make_file_hash(input_path)
        cache_key = make_cache_key(file_hash, selected_families, speed)
        render_data_diagnostics(quick_data_diagnostics(input_path))

        st.info(f"Input: {input_path.name} | Preset: {preset_name} | Families: {', '.join(selected_families) or 'diagnostics only'} | Quality: {speed_label}")

        if use_cached and cache_key in st.session_state["cfds_export_cache"]:
            st.success("Using cached result for this log/settings. No regeneration needed.")
            st.session_state["cfds_last_export"] = st.session_state["cfds_export_cache"][cache_key]
            # Rerun so the Export center renders outside this button-click block.
            # st.stop() would prevent cached downloads from appearing.
            st.rerun()

        progress = st.progress(0, text="Starting CFDS engine...")
        with st.spinner("Generating selected graphs inside the CFDS engine..."):
            progress.progress(20, text="Normalizing log and building diagnostics...")
            code, logs = run_worker(input_path, output_dir, mode, speed, selected_families)
            progress.progress(82, text="Packing exports and mobile previews...")

        if code != 0:
            st.error("CFDS generation failed. Open logs below, then download ZIP for diagnostics if available.")
        else:
            st.success("Graph generation completed.")

        show_report(output_dir)

        if code != 0 or show_logs_when_success:
            with st.expander("Worker logs", expanded=code != 0):
                st.code(logs[-20000:], language="text")

        st.session_state["cfds_last_export"] = collect_export_payload(output_dir, code, logs)
        st.session_state["cfds_export_cache"][cache_key] = st.session_state["cfds_last_export"]
        progress.progress(100, text="Done")

if st.session_state.get("cfds_last_export") is not None:
    show_previews_from_payload(st.session_state["cfds_last_export"], max_preview, show_full_png, show_all_folders)
    render_flight_replay(st.session_state["cfds_last_export"], mobile_fast=mobile_fast)
    show_export_center(st.session_state["cfds_last_export"])

st.divider()
st.caption("CFDS Web keeps the original graph engine, but uses a mobile-optimized browser interface for iPhone/iPad/desktop.")


# Final mobile readability override: Streamlit widgets can inherit muted opacity from
# internal wrappers on mobile. Keep this CSS at the end so it wins the cascade.
st.markdown(
    """
    <style>
    /* ---------- CFDS mobile control readability override ---------- */
    :root {
        --cfds-readable-text: #EAFBFF;
        --cfds-readable-muted: #BFD7EA;
        --cfds-readable-dim: #9DB7C9;
        --cfds-readable-panel: rgba(7,24,39,.94);
        --cfds-readable-card: rgba(14,43,69,.82);
        --cfds-readable-border: rgba(56,213,255,.36);
    }

    /* Global widget labels: fix dim/low-opacity Streamlit text on iPhone */
    [data-testid="stWidgetLabel"],
    [data-testid="stWidgetLabel"] *,
    [data-testid="stCheckbox"] label,
    [data-testid="stCheckbox"] label *,
    [data-testid="stRadio"] label,
    [data-testid="stRadio"] label *,
    [data-testid="stSlider"] label,
    [data-testid="stSlider"] label *,
    [data-testid="stSelectbox"] label,
    [data-testid="stSelectbox"] label *,
    [data-testid="stMultiSelect"] label,
    [data-testid="stMultiSelect"] label *,
    div[role="radiogroup"] label,
    div[role="radiogroup"] label *,
    div[data-testid="stMarkdownContainer"] p,
    div[data-testid="stCaptionContainer"],
    div[data-testid="stCaptionContainer"] * {
        color: var(--cfds-readable-text) !important;
        opacity: 1 !important;
        filter: none !important;
    }

    /* Secondary/help text should be readable, not nearly black */
    small, .stCaptionContainer, [data-testid="stHelp"], [data-testid="stTooltipIcon"] {
        color: var(--cfds-readable-muted) !important;
        opacity: 1 !important;
    }

    /* Radio/checkbox option rows: give each line enough visual weight */
    div[role="radiogroup"] > label,
    [data-testid="stCheckbox"] > label,
    [data-testid="stRadio"] > label {
        min-height: 2.05rem !important;
        align-items: center !important;
    }
    div[role="radiogroup"] p,
    [data-testid="stCheckbox"] p,
    [data-testid="stRadio"] p {
        font-size: .93rem !important;
        line-height: 1.35 !important;
        letter-spacing: .01em !important;
    }

    /* Section headers inside control panels */
    .cfds-panel h1, .cfds-panel h2, .cfds-panel h3,
    .cfds-panel p, .cfds-panel span, .cfds-panel label,
    .cfds-panel [data-testid="stMarkdownContainer"] * {
        color: var(--cfds-readable-text) !important;
        opacity: 1 !important;
    }
    .cfds-panel-title,
    .cfds-control-title,
    .cfds-replay-kicker {
        color: #38D5FF !important;
        opacity: 1 !important;
        text-shadow: 0 0 10px rgba(56,213,255,.20);
    }

    /* Selectbox / dropdown text */
    [data-baseweb="select"],
    [data-baseweb="select"] *,
    [data-baseweb="popover"] *,
    [data-baseweb="menu"] * {
        color: #071827 !important;
        opacity: 1 !important;
    }
    [data-baseweb="select"] > div {
        background: #F7FCFF !important;
        border: 1px solid rgba(56,213,255,.55) !important;
        border-radius: 12px !important;
    }

    /* Sliders: make numeric value and track easier to see */
    [data-testid="stSlider"] * {
        opacity: 1 !important;
    }
    [data-testid="stSlider"] [data-testid="stTickBar"] * {
        color: var(--cfds-readable-muted) !important;
    }
    [data-testid="stSlider"] div[role="slider"] {
        box-shadow: 0 0 0 4px rgba(255,75,85,.18) !important;
    }

    /* File uploader: remove white unreadable button / dim description */
    div[data-testid="stFileUploader"],
    div[data-testid="stFileUploader"] section,
    div[data-testid="stFileUploaderDropzone"] {
        background: var(--cfds-readable-card) !important;
        border: 1px dashed rgba(56,213,255,.50) !important;
        border-radius: 14px !important;
    }
    div[data-testid="stFileUploader"] *,
    div[data-testid="stFileUploaderDropzone"] * {
        color: var(--cfds-readable-text) !important;
        opacity: 1 !important;
    }
    div[data-testid="stFileUploader"] button,
    div[data-testid="stFileUploaderDropzone"] button {
        background: linear-gradient(180deg, #0EA5E9, #0369A1) !important;
        color: #FFFFFF !important;
        border: 1px solid rgba(234,251,255,.75) !important;
        border-radius: 12px !important;
        font-weight: 900 !important;
    }

    /* Panel/card readability on phones */
    .cfds-card, .metric-card, .replay-card,
    [data-testid="stExpander"],
    [data-testid="stVerticalBlockBorderWrapper"] {
        background: var(--cfds-readable-panel) !important;
        border-color: var(--cfds-readable-border) !important;
    }

    @media (max-width: 760px) {
        .block-container { padding-left: .72rem !important; padding-right: .72rem !important; }
        [data-testid="stWidgetLabel"] p,
        div[role="radiogroup"] p,
        [data-testid="stCheckbox"] p,
        [data-testid="stRadio"] p {
            font-size: .98rem !important;
            line-height: 1.45 !important;
        }
        .cfds-panel { padding: 1rem .95rem !important; }
        .cfds-panel-title { font-size: 1.02rem !important; letter-spacing: .16em !important; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# --- GLOBAL UI VISIBILITY HARDENING FIX (final override layer) ---
# Keep this block at the very end so it wins over older V12.56 skin rules and Streamlit defaults.
st.markdown(
    """
    <style>
    :root {
        --cfds-readable-text-strong: #F3FCFF;
        --cfds-readable-text: #DDF4FF;
        --cfds-readable-muted: #B7C9D9;
        --cfds-readable-dim: #8EA8BA;
        --cfds-readable-panel: #071827;
        --cfds-readable-card: #0B2136;
        --cfds-readable-card-2: #0E2B45;
        --cfds-readable-border: rgba(56, 213, 255, .42);
        --cfds-readable-border-soft: rgba(56, 213, 255, .24);
        --cfds-readable-cyan: #38D5FF;
        --cfds-readable-blue: #0B84FF;
        --cfds-readable-red: #FF4B55;
    }

    /* Global text hierarchy: no more dim labels on mobile */
    html, body, [data-testid="stAppViewContainer"], .stApp,
    [data-testid="stMarkdownContainer"], [data-testid="stMarkdownContainer"] *,
    [data-testid="stWidgetLabel"], [data-testid="stWidgetLabel"] *,
    label, label *, p, span, small, div[role="radiogroup"] *,
    [data-testid="stCheckbox"] *, [data-testid="stRadio"] *, [data-testid="stSlider"] *,
    [data-testid="stSelectbox"] *, [data-testid="stMultiSelect"] * {
        color: var(--cfds-readable-text) !important;
        opacity: 1 !important;
        text-shadow: none !important;
    }

    h1, h2, h3, h4, h5, h6,
    .cfds-panel-title, .cfds-control-title, .cfds-replay-kicker,
    .cfds-graph-titlebar h3 {
        color: var(--cfds-readable-cyan) !important;
        opacity: 1 !important;
        text-shadow: 0 0 10px rgba(56, 213, 255, .16) !important;
    }

    .stCaptionContainer, .stCaptionContainer *, small,
    .cfds-mobile-note, .cfds-replay-sub, .cfds-mini-help,
    .cfds-event-chip span, .cfds-status-cell span {
        color: var(--cfds-readable-muted) !important;
        opacity: 1 !important;
    }

    /* Panels/cards: visible edges and readable contents */
    .cfds-panel, .cfds-card, .metric-card, .replay-card,
    .cfds-control-block, .cfds-graph-card,
    [data-testid="stExpander"], [data-testid="stVerticalBlockBorderWrapper"] {
        background: rgba(7, 24, 39, .94) !important;
        border-color: var(--cfds-readable-border-soft) !important;
        color: var(--cfds-readable-text) !important;
    }

    /* Buttons should never become white-on-white or pale-on-white */
    .stButton button, .stDownloadButton button,
    div[data-testid="stFileUploader"] button,
    div[data-testid="stFileUploaderDropzone"] button {
        background: linear-gradient(180deg, #0B84FF, #005FB8) !important;
        color: #FFFFFF !important;
        border: 1px solid rgba(234, 251, 255, .75) !important;
        border-radius: 12px !important;
        font-weight: 900 !important;
        opacity: 1 !important;
    }
    .stButton button *, .stDownloadButton button *,
    div[data-testid="stFileUploader"] button *,
    div[data-testid="stFileUploaderDropzone"] button * {
        color: #FFFFFF !important;
        fill: #FFFFFF !important;
        opacity: 1 !important;
    }

    /* File uploader: full dropzone + selected file chip readability */
    div[data-testid="stFileUploader"] {
        background: rgba(7, 24, 39, .96) !important;
        border: 1px solid var(--cfds-readable-border-soft) !important;
        border-radius: 16px !important;
        padding: .65rem !important;
        color: var(--cfds-readable-text) !important;
    }
    div[data-testid="stFileUploader"] section,
    div[data-testid="stFileUploaderDropzone"] {
        background: rgba(11, 33, 54, .98) !important;
        border: 1px dashed var(--cfds-readable-border) !important;
        border-radius: 14px !important;
        color: var(--cfds-readable-text) !important;
    }
    div[data-testid="stFileUploader"] section *,
    div[data-testid="stFileUploaderDropzone"] *,
    div[data-testid="stFileUploader"] small,
    div[data-testid="stFileUploader"] label,
    div[data-testid="stFileUploader"] label * {
        color: var(--cfds-readable-text) !important;
        opacity: 1 !important;
    }
    div[data-testid="stFileUploader"] svg,
    div[data-testid="stFileUploaderDropzone"] svg {
        color: var(--cfds-readable-cyan) !important;
        fill: var(--cfds-readable-cyan) !important;
        opacity: 1 !important;
    }

    /* Uploaded-file chip selectors vary by Streamlit version; cover the common wrappers. */
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderFile"],
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderFile"] *,
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderFileName"],
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderFileSize"],
    div[data-testid="stFileUploader"] section + div,
    div[data-testid="stFileUploader"] section + div *,
    div[data-testid="stFileUploader"] [class*="uploaded"],
    div[data-testid="stFileUploader"] [class*="Uploaded"],
    div[data-testid="stFileUploader"] [class*="file"],
    div[data-testid="stFileUploader"] [class*="File"] {
        color: var(--cfds-readable-text-strong) !important;
        opacity: 1 !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderFile"],
    div[data-testid="stFileUploader"] section + div > div {
        background: var(--cfds-readable-card-2) !important;
        border: 1px solid var(--cfds-readable-border) !important;
        border-radius: 12px !important;
    }

    /* Inputs/select boxes: keep readable even if Streamlit theme creates white controls. */
    input, textarea, [data-baseweb="input"] *, [data-baseweb="textarea"] *,
    [data-baseweb="select"], [data-baseweb="select"] *,
    [data-baseweb="popover"] *, [data-baseweb="menu"] * {
        color: #06111F !important;
        opacity: 1 !important;
    }
    [data-baseweb="select"] > div,
    [data-baseweb="input"] > div,
    [data-baseweb="textarea"] > div {
        background: #F7FCFF !important;
        border: 1px solid rgba(56, 213, 255, .55) !important;
    }

    /* Checkbox/radio controls: label contrast and spacing */
    [data-testid="stCheckbox"] label,
    [data-testid="stRadio"] label,
    [data-testid="stCheckbox"] label *,
    [data-testid="stRadio"] label * {
        color: var(--cfds-readable-text) !important;
        opacity: 1 !important;
        line-height: 1.45 !important;
    }
    [data-testid="stCheckbox"] svg,
    [data-testid="stRadio"] svg {
        opacity: 1 !important;
        filter: drop-shadow(0 0 3px rgba(56,213,255,.18));
    }

    /* Slider text/ticks/value: brighter and separated */
    [data-testid="stSlider"] *,
    [data-testid="stSlider"] [data-testid="stTickBar"] * {
        color: var(--cfds-readable-text) !important;
        opacity: 1 !important;
    }
    [data-testid="stSlider"] div[role="slider"] {
        box-shadow: 0 0 0 4px rgba(255,75,85,.22), 0 0 10px rgba(255,75,85,.18) !important;
    }

    /* Mobile spacing: controls must breathe on iPhone */
    @media (max-width: 760px) {
        .block-container { padding-left: .85rem !important; padding-right: .85rem !important; }
        .cfds-panel, .cfds-control-block, .cfds-graph-card { padding: 1rem !important; }
        [data-testid="stWidgetLabel"] p,
        [data-testid="stCheckbox"] p,
        [data-testid="stRadio"] p,
        div[role="radiogroup"] p {
            font-size: 1rem !important;
            line-height: 1.55 !important;
        }
        [data-testid="stCheckbox"], [data-testid="stRadio"] {
            margin-bottom: .28rem !important;
        }
        div[data-testid="stFileUploader"] { padding: .75rem !important; }
        div[data-testid="stFileUploader"] section { min-height: 76px !important; }
        .cfds-panel-title { font-size: 1.02rem !important; letter-spacing: .14em !important; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Replay wide-layout final override: put controls above the graph and give Plotly max width.
st.markdown(
    """
    <style>
    .cfds-replay-wide-shell {
        padding: 1.05rem !important;
        max-width: 100% !important;
    }
    .cfds-wide-controls {
        border: 1px solid rgba(56,213,255,.34);
        background: linear-gradient(180deg, rgba(7,24,39,.92), rgba(5,11,18,.88));
        border-radius: 18px;
        padding: .95rem 1rem 1rem 1rem;
        margin: .85rem 0 .8rem 0;
        box-shadow: inset 0 1px 0 rgba(255,255,255,.05);
    }
    .cfds-wide-controls-title {
        color: #38D5FF;
        font-size: .82rem;
        letter-spacing: .18em;
        text-transform: uppercase;
        font-weight: 900;
        margin-bottom: .45rem;
    }
    .cfds-wide-status-strip {
        display: grid;
        grid-template-columns: repeat(5, minmax(0, 1fr));
        gap: .65rem;
        margin: .7rem 0 .8rem 0;
    }
    .cfds-graph-card-wide {
        padding: .75rem .85rem 1rem .85rem !important;
        width: 100% !important;
    }
    .cfds-graph-card-wide .js-plotly-plot,
    .cfds-graph-card-wide [data-testid="stPlotlyChart"] {
        width: 100% !important;
    }
    .cfds-event-strip-wide {
        margin-top: .7rem !important;
    }
    .cfds-wide-help {
        color: #BFD7EA !important;
        margin-top: .4rem;
        line-height: 1.55;
    }
    /* Make the modebar usable and visible on dark backgrounds. */
    .modebar {
        background: rgba(7,24,39,.90) !important;
        border: 1px solid rgba(56,213,255,.34) !important;
        border-radius: 10px !important;
        padding: 2px !important;
    }
    .modebar-btn svg path { fill: #DDF6FF !important; }
    .modebar-btn:hover svg path { fill: #38D5FF !important; }
    @media (max-width: 760px) {
        .cfds-wide-status-strip { grid-template-columns: 1fr 1fr; }
        .cfds-wide-controls { padding: .78rem .72rem; }
        .cfds-graph-card-wide { padding: .5rem !important; }
        .cfds-graph-card-wide [data-testid="stPlotlyChart"] { min-height: 520px; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# Replay spacing polish override: keep graph wide, but stop x-axis / state / event text from crowding.
st.markdown(
    """
    <style>
    .cfds-graph-card-wide {
        padding: .95rem 1rem 1.05rem 1rem !important;
        overflow: visible !important;
    }
    .cfds-graph-titlebar {
        display: flex !important;
        align-items: center !important;
        justify-content: flex-start !important;
        min-height: 2.35rem !important;
        padding: .22rem .25rem .72rem .25rem !important;
        margin-bottom: .15rem !important;
    }
    .cfds-graph-titlebar h3 {
        color: #EAFBFF !important;
        font-size: clamp(1.05rem, 1.4vw, 1.28rem) !important;
        letter-spacing: .11em !important;
        line-height: 1.25 !important;
        margin: 0 !important;
    }
    .cfds-graph-titlebar span { display: none !important; }

    .cfds-state-strip {
        display: grid !important;
        grid-template-columns: repeat(7, minmax(90px, 1fr)) !important;
        gap: .78rem !important;
        margin: 1.38rem .15rem .86rem .15rem !important;
        padding: .95rem .90rem .82rem .90rem !important;
        overflow-x: auto !important;
        align-items: stretch !important;
    }
    .cfds-state-strip-title {
        top: -.82rem !important;
        left: .90rem !important;
        font-size: .67rem !important;
        padding: 0 .55rem !important;
        letter-spacing: .13em !important;
    }
    .cfds-state-chip {
        min-height: 2.55rem !important;
        padding: .46rem .56rem !important;
        justify-content: center !important;
        gap: .42rem !important;
        line-height: 1.1 !important;
        white-space: nowrap !important;
        overflow: visible !important;
        text-overflow: clip !important;
    }
    .cfds-state-dot {
        width: .82rem !important;
        height: .82rem !important;
        min-width: .82rem !important;
    }

    .cfds-event-strip-wide {
        display: grid !important;
        grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)) !important;
        gap: .72rem !important;
        margin: .92rem .15rem .20rem .15rem !important;
    }
    .cfds-event-chip {
        min-height: 3.05rem !important;
        padding: .64rem .72rem !important;
    }
    .cfds-event-chip span {
        font-size: .66rem !important;
        line-height: 1.05 !important;
        margin-bottom: .18rem !important;
    }
    .cfds-event-chip b {
        font-size: .88rem !important;
        line-height: 1.15 !important;
    }

    .cfds-replay-tipbar {
        margin-top: .82rem !important;
        padding-top: .70rem !important;
        line-height: 1.55 !important;
    }

    .modebar {
        margin-top: .18rem !important;
        margin-right: .18rem !important;
        z-index: 20 !important;
    }

    @media (max-width: 760px) {
        .cfds-graph-card-wide { padding: .72rem .55rem .82rem .55rem !important; }
        .cfds-graph-titlebar { min-height: 2rem !important; padding-bottom: .55rem !important; }
        .cfds-state-strip {
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
            gap: .55rem !important;
            padding: .88rem .62rem .70rem .62rem !important;
            margin-top: 1.25rem !important;
        }
        .cfds-state-chip { justify-content: flex-start !important; min-height: 2.35rem !important; }
        .cfds-event-strip-wide { grid-template-columns: 1fr 1fr !important; gap: .55rem !important; }
        .cfds-event-chip { min-height: 2.75rem !important; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)
