# CFDS UI Upload/Text Visibility Fix

แก้ UI visibility ในหน้า Import/Generation:
- Upload label/text/help text อ่านง่ายขึ้นบน dark dashboard
- Upload button เป็น blue/cyan ชัดขึ้น ไม่ขาวซีด
- File uploader border/section contrast สูงขึ้น
- Checkbox/radio/slider labels ไม่จางจนมองยาก
- ไม่แตะ graph engine, replay state timing, export logic
