# Mobile Portrait Only Replay Fix

แก้เฉพาะปัญหา iPhone / มือถือแนวตั้ง โดยไม่เปลี่ยน desktop layout หลัก

## แก้ใน streamlit_app.py
- เพิ่ม CSS media query `@media (max-width: 768px)` สำหรับ replay panel เท่านั้น
- ลด padding/action deck บนมือถือ
- ซ่อน subtitle ยาวและ state/event strips ที่ซ้ำบนมือถือ
- ทำ jump chips เป็น horizontal scroll
- ทำ right status cards stack เป็น 1 column
- ป้องกัน Plotly กลายเป็นแท่งแคบด้วย width 100%
- เมื่อ `Mobile fast mode` เปิด จะปิด Plotly updatemenus/sliders ภายในกราฟ แล้วใช้ external chips แทน
- ใช้ `st.plotly_chart(..., width="stretch", theme=None, config=...)`

## Desktop
- คอม/desktop ใช้ layout เดิม ไม่ถูก media query เปลี่ยน

## Files
- streamlit_app.py
- .streamlit/config.toml (มีอยู่แล้วสำหรับ dark theme)
- elfaria_mascot.png (มีอยู่แล้ว)
