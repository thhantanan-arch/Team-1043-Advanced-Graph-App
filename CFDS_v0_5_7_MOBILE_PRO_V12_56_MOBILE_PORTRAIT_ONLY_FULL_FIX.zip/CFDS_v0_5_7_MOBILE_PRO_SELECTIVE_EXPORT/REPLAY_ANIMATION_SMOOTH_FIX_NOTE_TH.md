# CFDS Replay Animation Smooth Fix

ปรับ Flight Replay ให้ animation ลื่นขึ้นบน iPhone โดยเน้นลดภาระ browser ตอนกด Play

## สิ่งที่แก้
- เปลี่ยน replay dataframe ให้ใช้ time grid แบบสม่ำเสมอแทนการ downsample ตาม row index
- interpolate numeric telemetry เพื่อให้ current point เคลื่อนต่อเนื่องขึ้น
- static graph layers: state bands, event labels, full telemetry line, axes, grid
- animated layers เหลือแค่ current point และ time cursor
- ลด JSON/frame load เพราะไม่ redraw trail line ทั้งเส้นทุก frame
- คุม frame duration ตาม speed จริง: 1x = real mission speed
- slider steps ถูกทำให้ sparse เพื่อให้เบากว่า แต่ Play ยังใช้ทุก frame

## Recommended iPhone settings
- Speed: 5x
- Smoothness: 600 frames
- Trail: Full trail
- Replay engine: Smooth browser animation

## Notes
ถ้าต้องการ real-time playback จริง ให้ใช้ 1x แต่จะใช้เวลาตาม mission duration จริง เช่น mission 154 s จะเล่นประมาณ 154 s
