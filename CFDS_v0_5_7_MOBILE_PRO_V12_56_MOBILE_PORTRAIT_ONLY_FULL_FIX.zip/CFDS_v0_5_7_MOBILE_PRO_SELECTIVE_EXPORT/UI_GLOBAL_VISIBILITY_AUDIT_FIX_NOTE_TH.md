# UI Global Visibility Audit Fix

แก้ปัญหา control/text visibility ทั้งระบบบน iPhone:

- File uploader selected-file chip อ่านชัดขึ้น
- Upload button ไม่ white-on-white
- Label / checkbox / radio / slider / selectbox contrast สูงขึ้น
- Panel/card/control borders อ่านง่ายขึ้น
- เพิ่ม mobile spacing สำหรับ control groups
- ไม่แตะ replay graph logic, state timing, export engine

Important: CSS override block อยู่ท้าย `streamlit_app.py` เพื่อให้ชนะ Streamlit default/theme CSS.
