# GPS XY / XYZ + Motion Split + Descent Rate Fix

แก้ใน `streamlit_app.py`:

- เพิ่ม Replay graph options:
  - GPS XY path
  - GPS XYZ path
  - GPS map path
  - Acceleration magnitude
  - Acceleration XYZ
  - Gyro magnitude
  - Gyro XYZ
  - Tilt magnitude
  - Tilt XYZ
- `Velocity / Descent rate` จะ derive descent rate จาก altitude/time ถ้าไม่มี velocity column
- GPS XY path ใช้ local East/North meters จาก lat/lon เพื่อ replay ได้ smooth แบบ browser animation
- GPS XYZ path ใช้ East/North/Altitude เป็น 3D interactive path
- Motion XYZ แยกเป็นแต่ละ sensor family ไม่รวมเป็น Motion magnitude อันเดียว
- คง state timing / event detection / graph export engine เดิม

อัปเดต GitHub หลัก ๆ แค่ `streamlit_app.py`
