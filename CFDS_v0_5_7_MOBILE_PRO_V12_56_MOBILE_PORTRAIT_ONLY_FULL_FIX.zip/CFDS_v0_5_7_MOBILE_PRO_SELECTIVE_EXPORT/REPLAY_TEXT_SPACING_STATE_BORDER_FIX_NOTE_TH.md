# REPLAY_TEXT_SPACING_STATE_BORDER_FIX

แก้ Flight Replay แบบ visibility-first ตาม feedback:

- ไม่แตะ state timing / event detection
- ใช้ state highlight ในกราฟเหมือนเดิม แต่เพิ่ม border ของแต่ละ state band
- เพิ่ม boundary line ให้ state แยกง่ายขึ้นบน dark background
- ย้ายชื่อ state ออกจากพื้นที่ plot ไปเป็น State Colors strip ใต้กราฟ
- State Colors strip เปลี่ยนเป็น grid 7 ช่องบน desktop และ 2 columns บน iPhone
- ใช้ label สั้น: PAD / ASCENT / APOGEE / DESCENT / PROBE / PAYLOAD / LANDED
- ชื่อเต็มยังอยู่ใน tooltip/title ของ chip ไม่ทำให้หน้าแน่น
- เพิ่ม spacing ระหว่าง x-axis, State Colors, Event Timeline
- Event text อยู่ล่างกราฟเท่านั้น ไม่ทับเส้นข้อมูล

หลักการ highlight state ในกราฟ:
ใช้ contiguous STATE segments จาก normalized CSV แล้ววาดเป็น Plotly vertical rectangles ตามเวลา:
- x0 = state start time
- x1 = state end time
- fillcolor = state color
- line_color = brighter border color
- line_width = 2.1
- layer เป็น shape ใต้ data line

ไฟล์หลักที่แก้:
- streamlit_app.py
