# UI Mobile Control Readability Fix

แก้ visibility ของ control panel บน iPhone:

- เพิ่ม CSS override ท้ายไฟล์ให้ชนะ cascade ของ Streamlit
- ทำ label / checkbox / radio / slider / selectbox อ่านชัดขึ้น
- แก้ file uploader ไม่ให้ปุ่มขาวจาง
- เพิ่ม contrast ของ panel/card บน mobile
- ไม่แตะ replay graph logic, state timing, export engine

อัปเดตหลัก: `streamlit_app.py`
